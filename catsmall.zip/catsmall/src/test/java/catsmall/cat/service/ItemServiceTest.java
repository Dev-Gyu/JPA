package catsmall.cat.service;

import catsmall.cat.entity.dto.ItemTypeDto;
import catsmall.cat.entity.item.CatFood;
import catsmall.cat.entity.item.Item;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ItemServiceTest {
    @Autowired private ItemService itemService;

    @Test
    public void 상품서비스테스트() throws Exception{
        //given
        List<Item> all = itemService.findAll();

        //when
        for (Item item : all) {
            System.out.println((item instanceof CatFood));
            System.out.printf("name = %s , price = %d \n", item.getName(), item.getPrice());
        }

        List<ItemTypeDto> catFood = itemService.findItemTypesByCategory("CatFood");

        //then
        assertThat(catFood.size()).isEqualTo(3);
        assertThat(catFood.get(0)).extracting("categoryName").isEqualTo("CatFood");

    }

}