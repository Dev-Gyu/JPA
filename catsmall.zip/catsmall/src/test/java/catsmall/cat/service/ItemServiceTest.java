package catsmall.cat.service;

import catsmall.cat.entity.dto.item.ItemDto;
import catsmall.cat.entity.dto.ItemTypeDto;
import catsmall.cat.entity.item.CatFood;
import catsmall.cat.entity.item.Item;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class ItemServiceTest {
    @Autowired private ItemService itemService;

    @Test
    @Transactional
    public void 상품서비스테스트() throws Exception{
        //given
        List<Item> all = itemService.findAll();

        //when
        for (Item item : all) {
            System.out.println((item instanceof CatFood));
            System.out.printf("name = %s , price = %d \n", item.getName(), item.getPrice());
        }

        List<ItemTypeDto> catFood = itemService.findItemTypesByCategory("CatFood");
        List<ItemDto> result = itemService.findAllByType("CatFood", "junior");
        List<ItemDto> result2 = itemService.findAllByType("CatToilet", "소형");
        List<ItemDto> result3 = itemService.findAllByType("CatTower", "2floor");


        //then
        assertThat(result.get(0).getCategories().size()).isEqualTo(1);
        assertThat(result2.get(0).getCategories().size()).isEqualTo(1);
        assertThat(result3.get(0).getCategories().size()).isEqualTo(1);

        assertThat(result.get(0).getCategories()).extracting("category").extracting("name").containsExactly("CatFood");
        assertThat(result2.get(0).getCategories()).extracting("category").extracting("name").containsExactly("CatToilet");
        assertThat(result3.get(0).getCategories()).extracting("category").extracting("name").containsExactly("CatTower");


    }

}