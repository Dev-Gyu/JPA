package catsmall.cat.service;

import catsmall.cat.entity.Category;
import catsmall.cat.entity.ItemCategory;
import catsmall.cat.entity.item.CatFood;
import catsmall.cat.entity.item.Item;
import catsmall.cat.repository.ItemCategoryRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@Transactional
class CategoryServiceTest {
    @Autowired
    private EntityManager em;
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private ItemService itemService;
    @Autowired
    private ItemCategoryRepository itemCategoryRepository;

    @Test
    @Commit
    public void 카테고리테스트() throws Exception{
        //given
        Category catFood = new Category("CatFood");
        Category catToilet = new Category("CatToilet");
        Category catTower = new Category("CatTower");
        categoryService.save(catFood);
        categoryService.save(catToilet);
        categoryService.save(catTower);

        Item item1 = itemService.findById(2L);
        Item item2 = itemService.findById(3L);
        Item item3 = itemService.findById(4L);



        CatFood junior = (CatFood) item1;
        CatFood senior = (CatFood) item2;
        CatFood diet = (CatFood) item3;

        ItemCategory itemCategory = new ItemCategory(catFood, junior);
        ItemCategory itemCategory2 = new ItemCategory(catFood, senior);
        ItemCategory itemCategory3 = new ItemCategory(catFood, diet);
        itemCategoryRepository.save(itemCategory);
        itemCategoryRepository.save(itemCategory2);
        itemCategoryRepository.save(itemCategory3);

        em.flush();
        em.clear();
        //when
        Optional<ItemCategory> result = itemCategoryRepository.findById(11L);
        ItemCategory findItemCategory = result.get();
        List<ItemCategory> findItemCategories = itemCategoryRepository.findAllByCategoryId(8L);

        Category category = categoryService.findById(8L);
        category.deleteItem(findItemCategory);
        List<ItemCategory> findItemCategories2 = itemCategoryRepository.findAllByCategoryId(8L);


        //then
        assertThat(findItemCategories.size()).isEqualTo(3);
        assertThat(findItemCategories2.size()).isEqualTo(2);


    }
}