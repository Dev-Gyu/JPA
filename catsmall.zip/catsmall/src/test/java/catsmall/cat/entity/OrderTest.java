package catsmall.cat.entity;

import catsmall.cat.entity.item.CatFood;
import catsmall.cat.entity.item.Item;
import catsmall.cat.service.OrderService;
import org.assertj.core.api.Assertions;
import org.hibernate.jpa.internal.util.PersistenceUtilHelper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceUnitUtil;
import javax.persistence.PersistenceUtil;

import java.awt.print.Book;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
class OrderTest {
    @Autowired
    private EntityManager em;
    @Autowired
    private OrderService orderService;

    @Test
    @Commit
    public void 주문테스트() throws ClassNotFoundException {

    }

}