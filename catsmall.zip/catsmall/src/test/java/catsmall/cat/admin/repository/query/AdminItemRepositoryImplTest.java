package catsmall.cat.admin.repository.query;

import catsmall.cat.admin.repository.AdminItemRepository;
import catsmall.cat.entity.Category;
import catsmall.cat.entity.ItemCategory;
import catsmall.cat.entity.dto.item.ItemCategoryDto;
import catsmall.cat.entity.item.*;
import com.querydsl.core.Tuple;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static catsmall.cat.entity.item.QCatFood.catFood;
import static catsmall.cat.entity.item.QCatToilet.catToilet;
import static catsmall.cat.entity.item.QCatTower.catTower;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class AdminItemRepositoryImplTest {
    @Autowired
    AdminItemRepository adminItemRepository;

    @Test
    @Transactional
    public void 관리자상품리포지토리테스트() throws Exception {
        //given
        List<ItemCategory> result = adminItemRepository.findAllCategoryAndTypes();
        ItemCategoryDto itemCategoryDto = ItemCategoryDto.bindingItemCategory(result);
        List<Category> categories = itemCategoryDto.getCategories();
        List<CatFood> catFoods = itemCategoryDto.getCatFoods();
        List<CatToilet> catToilets = itemCategoryDto.getCatToilets();
        List<CatTower> catTowers = itemCategoryDto.getCatTowers();

        //when

        for (Category category : categories) {
            System.out.println("category = " + category.getName());
        }
        for (CatTower tower : catTowers) {
            System.out.println("type = " + tower.getType());
        }
        for (CatFood catFood : catFoods) {
            System.out.println("type = " + catFood.getType());
        }
        for (CatToilet catToilet : catToilets) {
            System.out.println("type = " + catToilet.getType());
        }


        //then

    }

}