package catsmall.cat.service;

import catsmall.cat.entity.Order;
import catsmall.cat.entity.OrderItem;
import catsmall.cat.repository.OrderItemRepository;
import catsmall.cat.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class OrderService {
    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;

    @Transactional
    public void cancelOrder(Long orderId, Long orderItemId){
        List<Order> orders = orderRepository.findOrdersByOrderId(orderId);
        OrderItem orderItem = orderItemRepository.findById(orderItemId).get();
        orders.get(0).cancelOrderItem(orderItem);
    }
}
