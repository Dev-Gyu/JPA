package catsmall.cat.service;

import catsmall.cat.entity.dto.ItemDto;
import catsmall.cat.entity.dto.ItemTypeDto;
import catsmall.cat.entity.item.CatFood;
import catsmall.cat.entity.item.CatToilet;
import catsmall.cat.entity.item.CatTower;
import catsmall.cat.entity.item.Item;
import catsmall.cat.repository.ItemRepository;
import com.querydsl.core.QueryResults;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ItemService {
    private final ItemRepository itemRepository;

    public List<Item> findAll(){
        return itemRepository.findAll();
    }

    public List<ItemTypeDto> findItemTypesByCategory(String category){
        return itemRepository.findItemTypesByCategory(category);
    }

    public Item findById(Long id, String category, String type){
        if(category.equals("CatFood")) {
            return itemRepository.findCatFoodByIdAndType(id, type);
        }else if(category.equals("CatToilet")){
            return itemRepository.findCatToiletByIdAndType(id, type);
        }else if(category.equals("CatTower")){
            return itemRepository.findCatTowerByIdAndType(id, type);
        }
        return null;
    }

    public List<ItemDto> findAllByType(String category, String type){
        return itemRepository.findAllCategoryItemByType(category, type);
    }
}
