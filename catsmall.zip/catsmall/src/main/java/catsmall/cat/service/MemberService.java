package catsmall.cat.service;

import catsmall.cat.entity.Member;
import catsmall.cat.entity.dto.LoginDto;
import catsmall.cat.entity.dto.MemberDto;
import catsmall.cat.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

@Service
@RequiredArgsConstructor
public class MemberService {
    private final MemberRepository memberRepository;

    public Member login(LoginDto loginDto, BindingResult errors){
        Member findMember = memberRepository.findMemberByEmail(loginDto.getEmail());
        if(findMember == null){
            errors.reject(null,"로그인에 실패하였습니다");
            return null;
        }
        if(!findMember.getPassword().equals(loginDto.getPassword())){
            errors.reject(null,"로그인에 실패하였습니다.");
            return null;
        }
        return findMember;
    }
    public void signup(MemberDto memberDto, BindingResult result){
        try {
            duplicationMemberCheck(memberDto.getEmail());
        }catch (Exception e){
            result.rejectValue("email",null,"중복된 이메일 입니다.");
            return;
        }
        Member member = Member.getMember(memberDto);
        memberRepository.save(member);
    }

    private void duplicationMemberCheck(String email){
        Member memberByEmail = memberRepository.findMemberByEmail(email);
        if(memberByEmail != null){
            throw new IllegalStateException("중복된 이메일 입니다");
        }
    }
}
