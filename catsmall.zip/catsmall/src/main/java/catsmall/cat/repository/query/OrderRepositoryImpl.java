package catsmall.cat.repository.query;

import catsmall.cat.entity.Order;
import catsmall.cat.entity.QOrder;
import catsmall.cat.entity.QOrderItem;
import catsmall.cat.entity.item.QItem;
import com.querydsl.jpa.impl.JPAQueryFactory;

import javax.persistence.EntityManager;
import java.util.List;

import static catsmall.cat.entity.QOrder.order;
import static catsmall.cat.entity.QOrderItem.orderItem;
import static catsmall.cat.entity.item.QItem.item;

public class OrderRepositoryImpl implements OrderQueryRepository{
    private final EntityManager em;
    private final JPAQueryFactory queryFactory;

    public OrderRepositoryImpl(EntityManager em){
        this.em = em;
        queryFactory = new JPAQueryFactory(em);
    }

    @Override
    public List<Order> findOrdersByOrderId(Long id){
        return queryFactory
                .selectFrom(order)
                .join(order.orderItems, orderItem).fetchJoin()
                .join(orderItem.item, item).fetchJoin()
                .where(order.id.eq(id))
                .fetch();
    }

}
