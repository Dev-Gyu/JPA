package catsmall.cat.repository;

import catsmall.cat.entity.Order;
import catsmall.cat.repository.query.OrderQueryRepository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

public interface OrderRepository extends JpaRepository<Order, Long>, OrderQueryRepository {
}
