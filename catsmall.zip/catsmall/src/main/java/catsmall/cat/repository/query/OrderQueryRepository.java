package catsmall.cat.repository.query;

import catsmall.cat.entity.Order;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface OrderQueryRepository {
    List<Order> findOrdersByOrderId(Long id);
}
