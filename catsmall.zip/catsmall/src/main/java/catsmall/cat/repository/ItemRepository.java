package catsmall.cat.repository;


import catsmall.cat.entity.item.CatFood;
import catsmall.cat.entity.item.CatToilet;
import catsmall.cat.entity.item.CatTower;
import catsmall.cat.entity.item.Item;
import catsmall.cat.repository.query.ItemQueryRepository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface ItemRepository extends JpaRepository<Item, Long>, ItemQueryRepository {
    CatFood findCatFoodByIdAndType(Long id, String type);
    CatToilet findCatToiletByIdAndType(Long id, String type);
    CatTower findCatTowerByIdAndType(Long id, String type);

}
