package catsmall.cat.repository.query;

import catsmall.cat.entity.dto.item.ItemDto;
import catsmall.cat.entity.dto.ItemTypeDto;

import java.util.List;

public interface ItemQueryRepository {
    List<ItemDto> findAllCategoryItemByType(String category, String type);


    List<ItemTypeDto> findItemTypesByCategory(String category);
}
