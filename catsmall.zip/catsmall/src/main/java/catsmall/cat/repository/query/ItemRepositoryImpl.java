package catsmall.cat.repository.query;

import catsmall.cat.entity.Category;
import catsmall.cat.entity.QCategory;
import catsmall.cat.entity.QItemCategory;
import catsmall.cat.entity.dto.ItemDto;
import catsmall.cat.entity.dto.ItemTypeDto;
import catsmall.cat.entity.item.*;
import com.querydsl.core.QueryResults;
import com.querydsl.core.types.Projections;
import com.querydsl.core.types.dsl.EntityPathBase;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.RequiredArgsConstructor;

import javax.persistence.EntityManager;

import java.util.List;

import static catsmall.cat.entity.QCategory.category;
import static catsmall.cat.entity.QItemCategory.itemCategory;
import static catsmall.cat.entity.item.QCatFood.catFood;
import static catsmall.cat.entity.item.QCatToilet.catToilet;
import static catsmall.cat.entity.item.QCatTower.catTower;
import static catsmall.cat.entity.item.QItem.item;

public class ItemRepositoryImpl implements ItemQueryRepository{

    private final EntityManager em;
    private final JPAQueryFactory queryFactory;

    public ItemRepositoryImpl(EntityManager em) {
        this.em = em;
        this.queryFactory = new JPAQueryFactory(em);
    }

    @Override
    public List<ItemTypeDto> findItemTypesByCategory(String category){
        return selectItemTypesByCategory(category);
    }
    private List<ItemTypeDto> selectItemTypesByCategory(String category){
        if(category.equals("CatTower")){
            return queryFactory
                    .select(Projections.bean(ItemTypeDto.class, catTower.type, QCategory.category.as("categoryName")))
                    .from(catTower)
                    .join(catTower.itemCategories, itemCategory)
                    .join(itemCategory.category, QCategory.category)
                    .where(QCategory.category.name.eq(category))
                    .fetch();
        }else if(category.equals("CatToilet")){
            return queryFactory
                    .select(Projections.bean(ItemTypeDto.class, catToilet.type, QCategory.category.as("categoryName")))
                    .from(catToilet)
                    .join(catToilet.itemCategories, itemCategory)
                    .join(itemCategory.category, QCategory.category)
                    .where(QCategory.category.name.eq(category))
                    .fetch();
        }else if(category.equals("CatFood")){
            return queryFactory
                    .select(Projections.bean(ItemTypeDto.class, catFood.type, QCategory.category.as("categoryName")))
                    .from(catFood)
                    .join(catFood.itemCategories, itemCategory)
                    .join(itemCategory.category, QCategory.category)
                    .where(QCategory.category.name.eq(category))
                    .fetch();
        }
        return null;
    }

    @Override
    public List<ItemDto> findAllCategoryItemByType(String category,String type){
        return selectQFileByType(category, type);
    }
    private List<ItemDto> selectQFileByType(String category, String type){
        if(category.equals("CatTower")) {
            return queryFactory
                    .select(Projections.bean(ItemDto.class, catTower.id, catTower.name, catTower.price, catTower.quantity))
                    .from(catTower)
                    .where(catTower.type.eq(type))
                    .fetch();
        }else if(category.equals("CatToilet")) {
            return queryFactory
                    .select(Projections.bean(ItemDto.class, catToilet.id, catToilet.name, catToilet.price, catToilet.quantity))
                    .from(catToilet)
                    .where(catToilet.type.eq(type))
                    .fetch();
        }else if(category.equals("CatFood")){
            return queryFactory
                    .select(Projections.bean(ItemDto.class, catFood.id, catFood.name, catFood.price, catFood.quantity))
                    .from(catFood)
                    .where(catFood.type.eq(type))
                    .fetch();
        }
        return null;
        }
    }
