package catsmall.cat.repository.query;

import catsmall.cat.entity.QCategory;
import catsmall.cat.entity.dto.item.ItemDto;
import catsmall.cat.entity.dto.ItemTypeDto;
import catsmall.cat.entity.item.*;
import com.querydsl.core.types.Projections;
import com.querydsl.jpa.impl.JPAQueryFactory;

import javax.persistence.EntityManager;

import java.util.List;

import static catsmall.cat.entity.QItemCategory.itemCategory;
import static catsmall.cat.entity.item.QCatFood.catFood;
import static catsmall.cat.entity.item.QCatToilet.catToilet;
import static catsmall.cat.entity.item.QCatTower.catTower;

public class ItemRepositoryImpl implements ItemQueryRepository {

    private final EntityManager em;
    private final JPAQueryFactory queryFactory;

    public ItemRepositoryImpl(EntityManager em) {
        this.em = em;
        this.queryFactory = new JPAQueryFactory(em);
    }

    @Override
    public List<ItemTypeDto> findItemTypesByCategory(String category) {
        return selectItemTypesByCategory(category);
    }

    private List<ItemTypeDto> selectItemTypesByCategory(String category) {
        if (category.equals("CatTower")) {
            return queryFactory
                    .select(Projections.bean(ItemTypeDto.class, catTower.type, QCategory.category.name.as("categoryName")))
                    .from(catTower)
                    .join(catTower.itemCategories, itemCategory)
                    .join(itemCategory.category, QCategory.category)
                    .where(QCategory.category.name.eq(category))
                    .fetch();
        } else if (category.equals("CatToilet")) {
            return queryFactory
                    .select(Projections.bean(ItemTypeDto.class, catToilet.type, QCategory.category.name.as("categoryName")))
                    .from(catToilet)
                    .join(catToilet.itemCategories, itemCategory)
                    .join(itemCategory.category, QCategory.category)
                    .where(QCategory.category.name.eq(category))
                    .fetch();
        } else if (category.equals("CatFood")) {
            return queryFactory
                    .select(Projections.bean(ItemTypeDto.class, catFood.type, QCategory.category.name.as("categoryName")))
                    .from(catFood)
                    .join(catFood.itemCategories, itemCategory)
                    .join(itemCategory.category, QCategory.category)
                    .where(QCategory.category.name.eq(category))
                    .fetch();
        }
        return null;
    }

    @Override
    public List<ItemDto> findAllCategoryItemByType(String category, String type) {
        return selectQFileByType(category, type);
    }

    private List<ItemDto> selectQFileByType(String category, String type) {
        if (category.equals("CatTower")) {
            List<ItemDto> itemDtos = queryFactory
                    .select(Projections.bean(ItemDto.class, catTower.id, catTower.name, catTower.price, catTower.quantity, catTower.type))
                    .from(catTower)
                    .where(catTower.type.eq(type))
                    .fetch();

            List<CatTower> catTowers = queryFactory
                    .selectFrom(catTower)
                    .join(catTower.itemCategories, itemCategory).fetchJoin()
                    .join(itemCategory.category, QCategory.category).fetchJoin()
                    .where(catTower.type.eq(type))
                    .fetch();

            catTowers.forEach(cf -> {
                itemDtos.forEach(itemDto -> itemDto.setCategories(cf.getItemCategories()));
            });
            return itemDtos;
        } else if (category.equals("CatToilet")) {
            List<ItemDto> itemDtos = queryFactory
                    .select(Projections.bean(ItemDto.class, catToilet.id, catToilet.name, catToilet.price, catToilet.quantity, catToilet.type))
                    .from(catToilet)
                    .where(catToilet.type.eq(type))
                    .fetch();

            List<CatToilet> catToilets = queryFactory
                    .selectFrom(catToilet)
                    .join(catToilet.itemCategories, itemCategory).fetchJoin()
                    .join(itemCategory.category, QCategory.category).fetchJoin()
                    .where(catToilet.type.eq(type))
                    .fetch();

            catToilets.forEach(cf -> {
                itemDtos.forEach(itemDto -> itemDto.setCategories(cf.getItemCategories()));
            });
            return itemDtos;

        } else if (category.equals("CatFood")) {
            List<ItemDto> itemDtos = queryFactory
                    .select(Projections.bean(ItemDto.class, catFood.id, catFood.name, catFood.price, catFood.quantity, catFood.type))
                    .from(catFood)
                    .where(catFood.type.eq(type))
                    .fetch();

            List<CatFood> catFoods = queryFactory
                    .selectFrom(catFood)
                    .join(catFood.itemCategories, itemCategory).fetchJoin()
                    .join(itemCategory.category, QCategory.category).fetchJoin()
                    .where(catFood.type.eq(type))
                    .fetch();
            catFoods.forEach(cf -> {
                itemDtos.forEach(itemDto -> itemDto.setCategories(cf.getItemCategories()));
            });
            return itemDtos;

        }
        return null;
    }
}
