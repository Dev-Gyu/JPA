package catsmall.cat.entity.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class ItemTypeDto {
    private String type;
    private String categoryName;

    public ItemTypeDto(String type, String categoryName) {
        this.type = type;
        this.categoryName = categoryName;
    }
}
