package catsmall.cat.entity.dto.item;

import catsmall.cat.entity.Category;
import catsmall.cat.entity.ItemCategory;
import catsmall.cat.entity.item.CatFood;
import catsmall.cat.entity.item.CatToilet;
import catsmall.cat.entity.item.CatTower;
import catsmall.cat.entity.item.Item;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

@Data
public class ItemCategoryDto {
    private List<Category> categories = new ArrayList<>();
    private List<CatFood> catFoods = new ArrayList<>();
    private List<CatToilet> catToilets = new ArrayList<>();
    private List<CatTower> catTowers = new ArrayList<>();

    public static ItemCategoryDto bindingItemCategory(List<ItemCategory> itemCategories) {
        ItemCategoryDto itemCategoryDto = new ItemCategoryDto();

        for (ItemCategory itemCategory : itemCategories) {
            if(!itemCategoryDto.categories.contains(itemCategory.getCategory())) {
                itemCategoryDto.categories.add(itemCategory.getCategory());
            }

            itemCategoryDto.selectAndBinding(itemCategory);
        }
        return itemCategoryDto;
    }

    private void selectAndBinding(ItemCategory itemCategory){
        Item item = itemCategory.getItem();
        if (itemCategory.getItem() instanceof CatFood) {
            if(!this.catFoods.contains(itemCategory.getItem()))
            this.catFoods.add((CatFood) item);
        } else if (itemCategory.getItem() instanceof CatToilet) {
            if(!this.catToilets.contains(itemCategory.getItem()))
            this.catToilets.add((CatToilet) item);
        } else if (itemCategory.getItem() instanceof CatTower) {
            if(!this.catTowers.contains(itemCategory.getItem()))
            this.catTowers.add((CatTower) item);
        }
    }
}
