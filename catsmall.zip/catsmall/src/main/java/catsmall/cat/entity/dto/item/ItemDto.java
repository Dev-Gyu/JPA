package catsmall.cat.entity.dto.item;

import catsmall.cat.entity.ItemCategory;
import catsmall.cat.entity.item.CatFood;
import catsmall.cat.entity.item.CatToilet;
import catsmall.cat.entity.item.Item;
import catsmall.cat.util.ItemUtils;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.NumberFormat;


import javax.annotation.RegEx;
import javax.validation.constraints.*;
import java.util.List;

@Data
@NoArgsConstructor
public class ItemDto {
    private Long id;
    @NotBlank
    private String name;
    @NotBlank
    @Min(message = "최소 1이상 입력해주세요", value = 1L)
    private String price;
    @NotBlank
    @Min(message = "최소 1이상 입력해주세요", value = 1L)
    private String quantity;
    @NotBlank(message = "카테고리를 선택해주세요")
    private String type;
    @NotBlank
    private String category;
    private List<ItemCategory> categories;

    public ItemDto(Long id, String name, String price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    public ItemDto(String name, String price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    public Item transformItem(ItemDto itemDto){
        Item tempItem = ItemUtils.getSubClassByCategory(itemDto.getCategory(), itemDto.getType());
        tempItem.setName(itemDto.getName());
        tempItem.setQuantity(Integer.parseInt(itemDto.getQuantity()));
        tempItem.setPrice(Integer.parseInt(itemDto.getPrice()));
        return tempItem;
    }
}
