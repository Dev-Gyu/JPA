package catsmall.cat.entity;

public enum OrderItemStatus {
    Order
}
