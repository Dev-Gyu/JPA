package catsmall.cat.entity.dto;

import catsmall.cat.entity.Address;
import catsmall.cat.entity.Role;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
public class MemberDto {
    private Long id;
    @NotEmpty
    private String email;
    @NotEmpty
    private String password;
    @NotEmpty
    private String name;
    @NotEmpty
    private String phonenum;
    @NotEmpty
    private String city;
    @NotEmpty
    private String street;
    @NotEmpty
    private String zipcode;
    private Role role = Role.USER;

    private Address address;

    public MemberDto(String email, String password, String name, String city, String street, String zipcode, String phonenum) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.phonenum = phonenum;
        Address address = new Address(city, street, zipcode);
        this.address = address;
    }
}
