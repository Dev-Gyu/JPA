package catsmall.cat.entity;

import catsmall.cat.entity.item.Item;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter @Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Category {
    @Id @GeneratedValue
    @Column(name = "category_id")
    private Long id;
    private String name;

    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private List<ItemCategory> itemCategory = new ArrayList<>();

    public Category(String name) {
        this.name = name;
    }

    public void addItem(ItemCategory itemCategory){
        this.itemCategory.add(itemCategory);
        itemCategory.setCategory(itemCategory.getCategory());
    }

    public void deleteItem(ItemCategory itemCategory){
        this.itemCategory.removeIf(ic -> {
            if(ic.getId() == itemCategory.getId()){
                return true;
            }
            return false;
        });
    }
}
