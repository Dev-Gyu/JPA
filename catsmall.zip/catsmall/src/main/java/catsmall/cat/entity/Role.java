package catsmall.cat.entity;

public enum Role {
    ADMIN, USER
}
