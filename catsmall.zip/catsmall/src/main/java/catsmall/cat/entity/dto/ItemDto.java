package catsmall.cat.entity.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class ItemDto {
    private Long id;
    private String name;
    private Integer price;
    private List<String> types;

    public ItemDto(Long id, String name, Integer price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    public ItemDto(String name, Integer price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }
}
