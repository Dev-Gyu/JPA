package catsmall.cat.entity;

import catsmall.cat.entity.dto.MemberDto;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter @Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Member {
    @Id @GeneratedValue
    @Column(name = "member_id")
    private Long id;
    private String email;
    private String password;
    private String name;
    private String phonenum;

    @Embedded
    private Address address;

    @OneToMany(mappedBy = "member", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Order> orders = new ArrayList<>();

    public Member(String email, String password, String name, String phonenum, Address address) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.phonenum = phonenum;
        this.address = address;
    }

    // business method
    public static Member getMember(MemberDto memberDto){
        return new Member(memberDto.getEmail(), memberDto.getPassword(),
                memberDto.getName(), memberDto.getPhonenum(),
                memberDto.getAddress());
    }
}
