package catsmall.cat.entity;

public enum OrderStatus {
    ORDER, CANCEL
}
