package catsmall.cat;

import catsmall.cat.entity.Address;
import catsmall.cat.entity.Category;
import catsmall.cat.entity.ItemCategory;
import catsmall.cat.entity.Member;
import catsmall.cat.entity.item.CatFood;
import catsmall.cat.entity.item.CatToilet;
import catsmall.cat.entity.item.Item;
import catsmall.cat.repository.CategoryRepository;
import catsmall.cat.repository.ItemCategoryRepository;
import catsmall.cat.service.CategoryService;
import catsmall.cat.service.ItemService;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;

@Component
@Getter @Setter
@RequiredArgsConstructor
public class PrepareClass {
    private final Prepare prepare;

    @PostConstruct
    public void init(){
        prepare.init();
    }

    @Component
    @Transactional
    @RequiredArgsConstructor
    static class Prepare{
        private final EntityManager em;
        @Autowired
        private CategoryService categoryService;
        @Autowired
        private ItemService itemService;
        @Autowired
        private ItemCategoryRepository itemCategoryRepository;

        public void init(){
            Address address = new Address("서울", "신림로", "11111");
            Member member = new Member("cjsworbehd13@naver.com", "vmffkd495", "규스", "01041638922", address);
            em.persist(member);
            CatFood junior = new CatFood("주니어사료", 10000,100,"junior");
            CatFood senior = new CatFood("시니어사료", 10000,100,"senior");
            CatFood diet = new CatFood("다이어트사료", 10000,100,"diet");
            em.persist(junior);
            em.persist(senior);
            em.persist(diet);
            CatToilet squareToilet = new CatToilet("사각화장실", 10000, 100, "소형");
            CatToilet roundToilet = new CatToilet("원형화장실", 10000, 100, "중형");
            CatToilet boxToilet = new CatToilet("박스형화장실", 10000, 100, "대형");
            em.persist(squareToilet);
            em.persist(roundToilet);
            em.persist(boxToilet);

            Category catFood = new Category("CatFood");
            Category catToilet = new Category("CatToilet");
            Category catTower = new Category("CatTower");
            categoryService.save(catFood);
            categoryService.save(catToilet);
            categoryService.save(catTower);

//            Item item1 = itemService.findById(2L, "CatFood", "junior");
//            Item item2 = itemService.findById(3L, "CatFood", "senior");
//            Item item3 = itemService.findById(4L, "CatFood", "diet");
//
//
//
//            CatFood junior1 = (CatFood) item1;
//            CatFood senior2 = (CatFood) item2;
//            CatFood diet3 = (CatFood) item3;

            ItemCategory itemCategory = new ItemCategory(catFood, junior);
            ItemCategory itemCategory2 = new ItemCategory(catFood, senior);
            ItemCategory itemCategory3 = new ItemCategory(catFood, diet);
            itemCategoryRepository.save(itemCategory);
            itemCategoryRepository.save(itemCategory2);
            itemCategoryRepository.save(itemCategory3);
        }
    }
}
