package catsmall.cat.admin.service;

import catsmall.cat.admin.repository.AdminCategoryRepository;
import catsmall.cat.entity.Category;
import catsmall.cat.entity.CategoryDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class AdminCategoryService {
    private final AdminCategoryRepository adminCategoryRepository;

    @Transactional
    public void save(CategoryDto categoryDto){
        Category category = new Category(categoryDto);
        adminCategoryRepository.save(category);
    }
}
