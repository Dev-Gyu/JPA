package catsmall.cat.admin.controller;

import catsmall.cat.admin.service.AdminCategoryService;
import catsmall.cat.admin.service.AdminItemService;
import catsmall.cat.entity.dto.item.ItemCategoryDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin/manage")
@RequiredArgsConstructor
public class AdminManageController {
    private final AdminItemService adminItemService;
    private final AdminCategoryService adminCategoryService;

    @GetMapping("/type")
    public String manageType(Model model){
        ItemCategoryDto itemCategoryDto = adminItemService.findAllCategoryAndTypes();
        model.addAttribute("itemCategoryDto", itemCategoryDto);
        return "admin/manage/type";
    }
}
