package catsmall.cat.admin.repository;

import catsmall.cat.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;


public interface AdminCategoryRepository extends JpaRepository<Category, Long> {
}
