package catsmall.cat.admin.controller;

import catsmall.cat.admin.repository.AdminItemRepository;
import catsmall.cat.admin.service.AdminCategoryService;
import catsmall.cat.admin.service.AdminItemService;
import catsmall.cat.entity.CategoryDto;
import catsmall.cat.entity.dto.ItemTypeDto;
import catsmall.cat.entity.dto.item.ItemCategoryDto;
import catsmall.cat.entity.dto.item.ItemDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;

@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {
    private final AdminCategoryService adminCategoryService;
    private final AdminItemService adminItemService;

    @GetMapping({"", "/"})
    public String admin_home(){
        return "admin/main";
    }
    @GetMapping("/addcategory")
    public String addCategory(@ModelAttribute("itemTypeDto") ItemTypeDto itemTypeDto,
                              Model model){
        ItemCategoryDto result = adminItemService.findAllCategoryAndTypes();
        model.addAttribute("itemCategoryDto", result);
        return "admin/category/add_category";
    }
    @PostMapping("/addcategory")
    public String addCategory_do(@ModelAttribute("itemTypeDto") ItemTypeDto itemTypeDto){
        adminItemService.addType(itemTypeDto);
        return "redirect:/admin";
    }

    @GetMapping("/additem")
    public String addItem(@ModelAttribute("itemDto") ItemDto itemDto,
                          Model model){
        ItemCategoryDto itemCategoryDto = adminItemService.findAllCategoryAndTypes();
        model.addAttribute("itemCategoryDto", itemCategoryDto);
        return "admin/item/add_item";
    }
    @PostMapping("/additem")
    public String additem_do(@Valid @ModelAttribute("itemDto") ItemDto itemDto,
                             BindingResult result,
                             Model model){
        if(result.hasErrors()){
            ItemCategoryDto itemCategoryDto = adminItemService.findAllCategoryAndTypes();
            model.addAttribute("itemCategoryDto", itemCategoryDto);
            return "admin/item/add_item";
        }
        adminItemService.addItem(itemDto);
        return "redirect:/admin";
    }
}
