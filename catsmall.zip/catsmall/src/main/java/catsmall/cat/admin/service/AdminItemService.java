package catsmall.cat.admin.service;

import catsmall.cat.admin.repository.AdminCategoryRepository;
import catsmall.cat.admin.repository.AdminItemCategoryRepository;
import catsmall.cat.admin.repository.AdminItemRepository;
import catsmall.cat.entity.Category;
import catsmall.cat.entity.ItemCategory;
import catsmall.cat.entity.dto.ItemTypeDto;
import catsmall.cat.entity.dto.item.ItemCategoryDto;
import catsmall.cat.entity.dto.item.ItemDto;
import catsmall.cat.entity.item.CatFood;
import catsmall.cat.entity.item.CatToilet;
import catsmall.cat.entity.item.CatTower;
import catsmall.cat.entity.item.Item;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class AdminItemService {
    private final AdminItemRepository adminItemRepository;
    private final AdminCategoryRepository adminCategoryRepository;
    private final AdminItemCategoryRepository adminItemCategoryRepository;

    public ItemCategoryDto findAllCategoryAndTypes(){
        List<ItemCategory> result = adminItemRepository.findAllCategoryAndTypes();
        ItemCategoryDto itemCategoryDto = ItemCategoryDto.bindingItemCategory(result);
        return itemCategoryDto;
    }
    public ItemCategoryDto findTypesByCategoryName(String category){
        List<ItemCategory> result = adminItemRepository.findTypesByCategoryName(category);
        ItemCategoryDto itemCategoryDto = ItemCategoryDto.bindingItemCategory(result);
        return itemCategoryDto;
    }

    @Transactional
    public void addType(ItemTypeDto itemTypeDto) {
        Item item = itemTypeDto.selectItemByType(itemTypeDto.getCategoryName(), itemTypeDto.getType());
        List<ItemCategory> itemCategories = adminItemRepository.findTypesByCategoryName(itemTypeDto.getCategoryName());
        Category category = itemCategories.get(0).getCategory();
        ItemCategory itemCategory = new ItemCategory(category, item);
        adminItemRepository.save(item);
        adminCategoryRepository.save(category);
    }

    @Transactional
    public void addItem(ItemDto itemDto) {
        Item item = itemDto.transformItem(itemDto);
        List<ItemCategory> itemCategories = adminItemRepository.findTypesByCategoryName(itemDto.getCategory());
        Category category = itemCategories.get(0).getCategory();
        ItemCategory itemCategory = new ItemCategory(category, item);
        adminItemRepository.save(item);
    }

    @Transactional
    public void modifyType(ItemTypeDto itemTypeDto){
        List<ItemCategory> itemCategory = adminItemRepository.findTypesByCategoryName(itemTypeDto.getCategoryName());
        itemCategory.forEach(ic -> {
            ic.getItem().changeItemType(itemTypeDto.getOriginType() ,itemTypeDto.getType());
        });
    }
    @Transactional
    public void deleteType(ItemTypeDto itemTypeDto){
        List<ItemCategory> itemCategories = adminItemRepository.findTypesByCategoryName(itemTypeDto.getCategoryName());
        List<Item> items = adminItemRepository.findAll();

        // Item Table 업데이트 메소드 ( 입력받은 카테고리에 해당하는 엔티티에 대한 타입중 입력된 타입을 제거하는 기능 )
        items.removeIf(it -> {
            String category = itemTypeDto.getCategoryName();
            if(it instanceof CatFood && category.equals("CatFood")){
                CatFood catFood = (CatFood) it;
                if(catFood.getType().equals(itemTypeDto.getType())){adminItemRepository.delete(catFood);}
            }else if(it instanceof CatToilet && category.equals("CatToilet")){
                CatToilet catToilet = (CatToilet) it;
                if(catToilet.getType().equals(itemTypeDto.getType())){adminItemRepository.delete(catToilet);}
            }else if(it instanceof CatTower && category.equals("CatTower")){
                CatTower catTower = (CatTower) it;
                if(catTower.getType().equals(itemTypeDto.getType())){adminItemRepository.delete(catTower);}
            }
            return false;
        });

        // ItemCategory Table 업데이트 메소드 ( 카테고리, 아이템과의 연관관계 끊음. 카테고리와 ophanremoval = true관계 )
        itemCategories.forEach(ic -> {
//             Category와 연관된 아이템카테고리들중 해당 아이템카테고리를 삭제
            ic.getCategory().getItemCategory().removeIf(cic -> {
                if(cic == ic){return true;}
                return false;
            });
        });

    }
}
