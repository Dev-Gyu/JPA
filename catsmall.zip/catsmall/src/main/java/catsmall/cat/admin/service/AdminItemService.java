package catsmall.cat.admin.service;

import catsmall.cat.admin.repository.AdminItemRepository;
import catsmall.cat.entity.ItemCategory;
import catsmall.cat.entity.dto.item.ItemCategoryDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class AdminItemService {
    private final AdminItemRepository adminItemRepository;

    public ItemCategoryDto findAllCategoryAndTypes(){
        List<ItemCategory> result = adminItemRepository.findAllCategoryAndTypes();
        ItemCategoryDto itemCategoryDto = ItemCategoryDto.bindingItemCategory(result);
        return itemCategoryDto;
    }
}
