package catsmall.cat.admin.repository.query;

import catsmall.cat.admin.repository.AdminItemRepository;
import catsmall.cat.entity.ItemCategory;
import catsmall.cat.entity.QCategory;
import catsmall.cat.entity.QItemCategory;
import catsmall.cat.entity.item.*;
import com.querydsl.core.Tuple;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.persistence.EntityManager;

import java.util.List;
import java.util.stream.Collectors;

import static catsmall.cat.entity.QCategory.category;
import static catsmall.cat.entity.QItemCategory.itemCategory;
import static catsmall.cat.entity.item.QCatFood.catFood;
import static catsmall.cat.entity.item.QCatToilet.catToilet;
import static catsmall.cat.entity.item.QCatTower.catTower;
import static catsmall.cat.entity.item.QItem.item;

public class AdminItemRepositoryImpl implements AdminItemQueryRepository{
    private final JdbcTemplate jdbcTemplate;
    private final EntityManager em;
    private final JPAQueryFactory queryFactory;

    public AdminItemRepositoryImpl(EntityManager em, JdbcTemplate jdbcTemplate){
        this.em = em;
        queryFactory = new JPAQueryFactory(em);
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<ItemCategory> findAllCategoryAndTypes(){
        List<ItemCategory> fetch = queryFactory
                .select(itemCategory)
                .distinct()
                .from(itemCategory)
                .join(itemCategory.category, category).fetchJoin()
                .join(itemCategory.item, item).fetchJoin()
                .fetch();
        return fetch;
    }

    @Override
    public List<Item> findTypesByCategoryName(String category){
        queryFactory
                .selectFrom(ca)
    }
}
