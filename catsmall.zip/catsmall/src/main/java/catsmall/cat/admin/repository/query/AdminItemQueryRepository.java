package catsmall.cat.admin.repository.query;

import catsmall.cat.entity.ItemCategory;
import com.querydsl.core.Tuple;

import java.util.List;

public interface AdminItemQueryRepository {
    List<ItemCategory> findAllCategoryAndTypes();
}
