package catsmall.cat.admin.repository.query;

import catsmall.cat.entity.ItemCategory;
import catsmall.cat.entity.item.Item;
import com.querydsl.core.Tuple;

import java.util.List;

public interface AdminItemQueryRepository {
    List<ItemCategory> findAllCategoryAndTypes();
    List<ItemCategory> findTypesByCategoryName(String category);
}
