package catsmall.cat.admin.controller;

import catsmall.cat.admin.service.AdminItemService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/admin/api")
public class AdminRestController {
    private final AdminItemService adminItemService;

    @GetMapping("/getSubCategories")
    public RestWrapper getSubCategories(@RequestParam("categoryValue") String category){
        System.out.println(category);
        adminItemService.
        return null;
    }

    static class RestWrapper{

    }
}
