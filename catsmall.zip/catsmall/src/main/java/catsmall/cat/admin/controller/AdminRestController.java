package catsmall.cat.admin.controller;

import catsmall.cat.admin.service.AdminItemService;
import catsmall.cat.entity.dto.ItemTypeDto;
import catsmall.cat.entity.dto.item.ItemCategoryDto;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/admin/api")
public class AdminRestController {
    private final AdminItemService adminItemService;

    @PostMapping("/getSubCategories")
    public RestWrapper getSubCategories(@RequestBody ItemTypeDto itemTypeDto){
        System.out.println(itemTypeDto.getCategoryName());
        ItemCategoryDto result = adminItemService.findTypesByCategoryName(itemTypeDto.getCategoryName());
        RestWrapper restWrapper = new RestWrapper(result);
        return restWrapper;
    }

    @PostMapping("/modifyType")
    public String modifyType(@RequestBody ItemTypeDto itemTypeDto){
        adminItemService.modifyType(itemTypeDto);
        return "success";
    }

    @DeleteMapping("/deleteType")
    public String deleteType(@RequestBody ItemTypeDto itemTypeDto){
        System.out.println(itemTypeDto.getCategoryName());
        System.out.println(itemTypeDto.getType());
        adminItemService.deleteType(itemTypeDto);
        return "success";
    }

    @Data
    static class RestWrapper{
        private ItemCategoryDto itemCategoryDto;

        public RestWrapper(ItemCategoryDto itemCategoryDto) {
            this.itemCategoryDto = itemCategoryDto;
        }
    }
}
