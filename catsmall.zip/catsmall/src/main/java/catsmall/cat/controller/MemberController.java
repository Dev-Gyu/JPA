package catsmall.cat.controller;

import catsmall.cat.entity.Member;
import catsmall.cat.entity.dto.LoginDto;
import catsmall.cat.entity.dto.MemberDto;
import catsmall.cat.repository.MemberRepository;
import catsmall.cat.service.MemberService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
@RequestMapping("/members")
@RequiredArgsConstructor
public class MemberController {
    private final MemberService memberService;

    /**
     * 로그인
     */
    @GetMapping("/signin")
    public String signin(@ModelAttribute("loginDto")LoginDto loginDto){
        return "member/signin";
    }

    @PostMapping("/signin")
    public String signin_do(@Valid @ModelAttribute("loginDto") LoginDto loginDto, BindingResult errors,
                            HttpSession session){
        if(errors.hasErrors()){
            return "member/signin";
        }
        Member loginInfo = memberService.login(loginDto, errors);
        if(errors.hasErrors()){
            return "member/signin";
        }
        session.setAttribute("loginInfo", loginInfo);
        return "redirect:/";
    }
    /**
     * 로그아웃
     */
    @GetMapping("/logout")
    public String logout(HttpSession session){
        session.removeAttribute("loginInfo");
        return "redirect:/";
    }

    /**
     * 회원가입
     */

    @GetMapping("/signup")
    public String signup(@ModelAttribute("memberDto") MemberDto memberDto){
        return "member/signup";
    }
    @PostMapping("/signup")
    public String signup_do(@Valid @ModelAttribute("memberDto") MemberDto memberDto,
                            BindingResult result){
        if(result.hasErrors()){
            return "member/signup";
        }
        memberService.signup(memberDto, result);
        if(result.hasErrors()){
            return "member/signup";
        }
        return "redirect:/";
    }

    @GetMapping("/mypage")
    public String mypage(){
        return null;
    }
}
