package catsmall.cat.controller;

import catsmall.cat.entity.dto.ItemDto;
import catsmall.cat.entity.dto.ItemTypeDto;
import catsmall.cat.entity.item.Item;
import catsmall.cat.service.ItemService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/board")
public class BoardController {
    private final ItemService itemService;

    @GetMapping(value = {"/",""})
    public String main(@RequestParam("category") String category,
                       @RequestParam("type") String type,
                       Model model){

        List<ItemDto> itemDtos = itemService.findAllByType(category, type);
        List<ItemTypeDto> itemTypes = itemService.findItemTypesByCategory(category);
        model.addAttribute("type", type);
        model.addAttribute("itemTypes", itemTypes);
        model.addAttribute("items", itemDtos);
        return "board/itemlist";
    }
}
