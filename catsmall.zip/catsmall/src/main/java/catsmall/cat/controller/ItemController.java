package catsmall.cat.controller;

import catsmall.cat.entity.item.Item;
import catsmall.cat.repository.ItemRepository;
import catsmall.cat.service.ItemService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Optional;

@Controller
@RequestMapping("/item")
@RequiredArgsConstructor
public class ItemController {
    private final ItemService itemService;

    @Transactional
    @GetMapping(value = "/main/{id}")
    public String main(@PathVariable("id") Long itemId, Model model){
        return null;
    }
}
