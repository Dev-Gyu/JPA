package catsmall.cat.controller;

import catsmall.cat.entity.dto.ItemTypeDto;
import catsmall.cat.entity.item.Item;
import catsmall.cat.repository.ItemRepository;
import catsmall.cat.service.ItemService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/item")
@RequiredArgsConstructor
public class ItemController {
    private final ItemService itemService;

    @GetMapping(value = "/main")
    public String main(@RequestParam("item") Long itemId,
                       @RequestParam("category") String category,
                       @RequestParam("type") String type,
                       Model model){
        Item item = itemService.findById(itemId);
        List<ItemTypeDto> itemTypes = itemService.findItemTypesByCategory(category);
        model.addAttribute("item", item);
        model.addAttribute("type", type);
        model.addAttribute("itemTypes", itemTypes);
        return "board/item_detail";
    }
}
