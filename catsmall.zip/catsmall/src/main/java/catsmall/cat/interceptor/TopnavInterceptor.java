package catsmall.cat.interceptor;

import catsmall.cat.entity.Category;
import catsmall.cat.entity.Member;
import catsmall.cat.entity.Role;
import catsmall.cat.service.CategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;

public class TopnavInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        HttpSession session = request.getSession();
        Member loginInfo = (Member) session.getAttribute("loginInfo");
        if(loginInfo != null){
            request.setAttribute("role", loginInfo.getRole().toString());
        }
        return true;
    }
}
