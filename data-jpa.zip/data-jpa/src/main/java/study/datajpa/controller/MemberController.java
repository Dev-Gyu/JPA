package study.datajpa.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import study.datajpa.dto.MemberDto;
import study.datajpa.entity.Member;
import study.datajpa.repository.MemberRepository;

import javax.annotation.PostConstruct;

@RestController
@RequiredArgsConstructor
public class MemberController {

    private final MemberRepository memberRepository;

    @GetMapping("/members/{id}")
    public String findMember(@PathVariable("id") Long id){
        Member member = memberRepository.findById(id).get();
        return member.getUsername();
    }

    // Spring Data Jpa가 자동으로 바인딩 다 해줌. 하지만 조금만 복잡해지면 쓰기 어려움. -> 잘 안씀
    // 또한 트랜잭션상태에서 조회한게 아니기때문에 영속성컨텍스트의 관리대상이 아님 -> 조회용 으로만 사용할것
    @GetMapping("/members2/{id}")
    public String findMember2(@PathVariable("id") Member member){
        return member.getUsername();
    }

    /**
     * 컨트롤러에서 파라미터가 바인딩될때 바인딩될 객체중 Pageable 객체가 있으면 내부적으로 PageRequest객체를 구현해 파라미터를 필드로 바인딩해줌
     * 스프링 부트가 알아서 설정 다 잡아주는 것.
     * 파라미터: page=숫자, size=숫자, sort=정렬정책 ( Page는 0부터 시작함. 1부터 시작하려면 PageRequest, Page<> 다 새로 만들어주면됨 )
     * 글로벌로 설정하고 싶으면 application.yml에 default-page-size, max-page-size 설정하면됨. 적용 우선순위 로컬 > 글로벌
     * @PageableDefault = url에 파라미터가 없어도 페이징처리 가능하도록 해주는 애노테이션 (로컬)
     * 그리고 엔티티 반환하지말고 DTO반드시 쓸것
     */
    @GetMapping("/members")
    public Page<MemberDto> list(@PageableDefault(size = 5) Pageable pageable){
        return memberRepository.findAll(pageable)
                .map(m -> new MemberDto(m.getId(), m.getUsername(), null));
    }

    // Spring이 DI주입 후 init()메소드 호출하는데, 이때 처음에 실행해줘야 할 메소드들을 정의해줌
    @PostConstruct
    public void init(){
        for(int i=0; i<100; i++){
            memberRepository.save(new Member("user"+i, i));
        }
    }
}
