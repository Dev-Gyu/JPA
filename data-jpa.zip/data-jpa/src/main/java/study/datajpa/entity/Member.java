package study.datajpa.entity;

import lombok.*;

import javax.persistence.*;

@Entity
@Getter @Setter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@ToString(of = {"id", "username", "age"})   // toString 메소드 생성해주는 애노테이션, 무한루프빠지지않게하기위해 team빼줌
// 정적 쿼리를 사용하기 때문에 Application실행시 Parsing했을때 쿼리에 문제가 있으면 Application실행시점에서 예외발생해줌
// 실무에선 잘 안쓰고, Spring data JPA에서 지원해주는 기능을 사용함
@NamedQuery(
        name = "Member.findByUsername",
        query="select m from Member m where m.username = :username"
)
public class Member extends JpaBaseEntity{
    @Id @GeneratedValue
    @Column(name = "member_id")
    private Long id;
    private String username;
    private int age;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "team_id")
    private Team team;

    public Member(String username) {
        this.username = username;
    }

    public Member(String username, int age, Team team) {
        this.username = username;
        this.age = age;
        if(team != null) {
            changeTeam(team);
        }
    }

    public Member(String username, int age) {
        this.username = username;
        this.age = age;
    }

    // 연관관계 편의성 메소드 추가
    public void changeTeam(Team team){
        this.team = team;
        team.getMembers().add(this);
    }

}
