package study.datajpa.entity;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.domain.Persistable;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.time.LocalDateTime;

@Entity
@EntityListeners(AuditingEntityListener.class)
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Item implements Persistable {
    /**
     * Spring Data JPA의 구현체에서의 save()는 기본적으로 @Id가 붙은 필드값이 초기값인지 아닌지를 보고 새로운 엔티티 여부를 판단함
     * 만약 save()호출 당시 id값이 초기값이 아닌경우, 즉 참조형은 Null, 정수형은 0이 아닌경우엔 이미 DB에 존재하는 엔티티라고 판단하여
     * persist()를 호출하는게 아니라 merge()를 호출함. <- 구현체 가서 save()보면 바로보임
     * 만약 id가 기본형이아니고 save호출전에 값을 미리 세팅하거나, GeneratedValue로 설정해둔다면 이미 save진입전 PK값이 세팅되어 들어가므로
     * merge가 호출되고 이로인해 DB에서 PK값으로 조회한뒤 조회결과가 없으면 persist를 수행하기때문에.. 매우 비효율적임
     * 따라서 엔티티에 Persistable 인터페이스 구현해서 isNew를 오버라이딩하는것을 추천. @CreatedDate 이용해서 신규 엔티티인지 확인하는거 추천
     */
    @Id @GeneratedValue
    private Long id;

    private String name;

    @CreatedDate
    private LocalDateTime createdDate;

    public Item(String name){
        this.name = name;
    }

    @Override
    public Object getId() {
        return id;
    }

    @Override
    public boolean isNew() {
        return createdDate == null;
    }
}
