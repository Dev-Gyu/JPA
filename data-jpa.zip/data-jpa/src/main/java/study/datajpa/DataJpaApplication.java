package study.datajpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import java.util.Optional;
import java.util.UUID;

@EnableJpaAuditing // @MappedSuperClass Spring Data JPA로 쓰려면 선언해줘야됨
@SpringBootApplication
public class DataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataJpaApplication.class, args);
	}

	@Bean
	public AuditorAware<String> auditorProvider(){
		// 반환하는타입 = AuditorAware<String> <- 등록,수정할때마다 @CreatedBy, @LastModifiedBy호출해서 인자로 받은값 저장함
		// 실제로 쓰려면 세션에 로그인정보 가져와서 쓰던지, SpringSecurity쓰면 SecurityContextHolder의 정보가져오던지 하면됨
		return () -> Optional.of(UUID.randomUUID().toString());
	}
}
