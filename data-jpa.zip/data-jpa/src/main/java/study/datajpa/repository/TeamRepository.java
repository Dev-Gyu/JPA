package study.datajpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import study.datajpa.entity.Team;

//@Repository JpaRepository 상속하면 선언 안해줘도됨
public interface TeamRepository extends JpaRepository<Team, Long> {

}
