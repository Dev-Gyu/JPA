package study.datajpa.repository;

import study.datajpa.entity.Member;

import java.util.List;

/**
 * 사용자 정의 리포지토리 구현.
 * 개발자가 JPA를 직접이용하거나 MyBatis, JDBC, QueryDSL등을 이용할때 JPARepository를 상속받은 인터페이스를 구현하게되면 엄청난 메소드를 다 구현해야함.
 * 이를 막기위해 다음과 같은 방식을 사용함
 */
public interface MemberRepositoryCustom {
    List<Member> findMemberCustom();
}
