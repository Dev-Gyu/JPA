package study.datajpa.repository;

import org.springframework.beans.factory.annotation.Value;

// 프로젝션 사용하는 인터페이스
public interface UsernameOnly {
    //String getUsername();

    // Open Projections <- 엔티티 데이터 전부 다 갖고와서 Value조건에 맞게끔 바인딩해줌
    @Value("#{target.username + ' ' + target.age}")
    String getUsername();
}
