package study.datajpa.repository;

public interface MemberProjection {

    Long getId();
    String getUsername();
    String getTeamName();
}
