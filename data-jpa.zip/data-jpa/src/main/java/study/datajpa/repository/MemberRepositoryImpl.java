package study.datajpa.repository;

import lombok.RequiredArgsConstructor;
import study.datajpa.entity.Member;

import javax.persistence.EntityManager;
import java.util.List;

@RequiredArgsConstructor
// 커스텀 Repository 사용할경우 JpaRepository상속받은 인터페이스명+Impl 로 클래스명 맞춰줘야함
public class MemberRepositoryImpl implements MemberRepositoryCustom{
    /**
     * 주입받아 사용하는건 JDBC, MyBatis 등 뭘 써도 됨
     */
    private final EntityManager em;

    @Override
    public List<Member> findMemberCustom(){
        return em.createQuery("select m from Member m")
                .getResultList();
    }
}
