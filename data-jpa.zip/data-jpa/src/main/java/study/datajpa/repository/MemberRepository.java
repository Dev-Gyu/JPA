package study.datajpa.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import study.datajpa.dto.MemberDto;
import study.datajpa.entity.Member;

import javax.persistence.QueryHint;
import java.util.Collection;
import java.util.List;
import java.util.Optional;



// JpaRepository<T,V> T = Entity명, V = EntityPK명
public interface MemberRepository extends JpaRepository<Member, Long>, MemberRepositoryCustom {

    // 간단한 쿼리같은경우 메소드 명으로 쿼리를 생성해주는 방법 사용
    List<Member> findByUsernameAndAgeGreaterThan(String username2, int age);


    // 이 기능을 많이 씀. 쿼리에 오류가 있으면 application loading시 예외발생
    // Application실행시 정적쿼리기때문에 Parsing해버림. 좀 복잡해지면 이 방법써서 실행하는거 추천
    // 파라미터 바인딩 = 위치기반, 이름기반 있는데 이름기반만 쓸것, 메소드 인자에 @Param("쿼리의 파라미터명") 써주면 알아서 바인딩됨
    @Query("select m from Member m where m.username = :username and m.age = :age")
    List<Member> findUser(@Param("username") String username, @Param("age") int age);

    // 필드 하나 지정해서 값 가져오기
    @Query("select m.username from Member m")
    List<String> findUsernameList();

    // DTO로 값 바로 조회하기, 역시 이것도 queryDSL쓰면 훨씬 편하다.
    @Query("select new study.datajpa.dto.MemberDto(m.id, m.username, t.name) from Member m join m.team t")
    List<MemberDto> findMemberDto();

    // 쿼리에 여러개 파라미터값 바인딩해서 가져오는법
    @Query("select m from Member m  where m.username in :usernames")
    List<Member> findByNames(@Param("usernames")Collection<String> names);


    // Spring JPA의 반환 타입 종류, 메소드명으로 쿼리 생성하는 방식
    List<Member> findListByUsername(String username); // 컬렉션 반환
    Member findMemberByUsername(String username); // 단건 반환
    Optional<Member> findOptionByUsername(String username); // 단건 Optional반환

    // Spring Data Jpa로 페이징하는법
    // 만약 Join할때 Data갯수에 변화가 없다면 Count 쿼리를 별도로 분리해 작성하는것이 권장된다.
    // 안해주면 CountQuery에도 Join이 걸려서 성능이저하됨
    @Query(value = "select m from Member m", countQuery = "select count(m.username) from Member m")
    Page<Member> findByAge(int age, Pageable pageable);
//     Slice<Member> findByAge(int age, Pageable pageable);

    // Spring Data Jpa이용 bulk연산
    // @Modifying = 쿼리 실행하고 .executeUpdate() 실행해주는역할 (없으면 예외발생해버림)
    @Modifying(clearAutomatically = true) // clearAutomatically = true <- 벌크연산 실행하고 영속성컨텍스트 자동으로 clear해주는 기능
    @Query("update Member m set m.age = :age + 1 where m.age >= :age")
    int bulkAgePlus(@Param("age") int age);

    @Query("select m from Member m join fetch m.team")
    List<Member> findMemberFetchJoin();

    // JPQL안쓰고도 페치조인 해오는법
    @Override
    @EntityGraph(attributePaths = {"team"})
    List<Member> findAll();

    // JPQL에 EntityGraph만 추가해서 페치조인 하는법
    @EntityGraph(attributePaths = {"team"})
    @Query("select m from Member m")
    List<Member> findMemberEntityGraph();

    // 메소드명으로 EntityGraph추가해서 페치조인 하는법
    @EntityGraph(attributePaths = {"team"})
    List<Member> findEntityGraphByUsername(@Param("username") String username);

    // 특정용도로만으로 객체를 반환해서 사용할 수 있도록 최적화해주는 기능
    // 성능최적화를 해보고 꼭 필요한곳에서만 쓰는게 좋음.. 그런데 이걸써야할만큼 성능최적화를할정도면 이미 다른 대안을 써야하는 시점이 될것이다.
    @QueryHints(value = @QueryHint(name = "org.hibernate.readOnly", value = "true"))
    Member findReadOnlyByUsername(String name);

    List<UsernameOnly> findProjectionsByUsername(@Param("username") String username);

    // Dto 생성자 인자 파라미터명으로 프로젝션
    List<UsernameOnlyDto> findProjectionsDtoByUsername(@Param("username") String username);

    // Dto 생성자 인자 파라미터명으로 프로젝션
    <T> List<T> findProjectionsGenericByUsername(@Param("username") String username, Class<T> type);

    /**
     * Native Query
     */
    @Query(value = "select * from Member where username = :username", nativeQuery = true)
    Member findByNativeQuery(@Param("username") String username);

    // 네이티브쿼리 사용할때 프로젝션 이용해서 페이징처리까지 하는법, 정적쿼리에 한해선 어느정도 커버 할 수 있다.
    // 근데 이것보단 동적쿼리도 커버할수 있는 마이바티스, JDBC Template를 써라
    @Query(value = "select m.member_id as id, m.username, t.name as teamName " +
                    "from member m left join team t",
                    countQuery = "select count(*) from member",
                    nativeQuery = true)
    Page<MemberProjection> findByNativeProjection(Pageable pageable);
}
