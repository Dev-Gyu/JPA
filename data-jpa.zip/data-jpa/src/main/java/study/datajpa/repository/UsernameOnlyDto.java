package study.datajpa.repository;

// 생성자 인자의 parameter명으로 projection도 가능함
public class UsernameOnlyDto {

    private final String username;

    public UsernameOnlyDto(String username){
        this.username = username;
    }

    public String getUsername(){
        return username;
    }
}
