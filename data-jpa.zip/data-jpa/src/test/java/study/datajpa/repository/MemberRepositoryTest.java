package study.datajpa.repository;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Slice;
import org.springframework.data.domain.Sort;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;
import study.datajpa.dto.MemberDto;
import study.datajpa.entity.Member;
import study.datajpa.entity.Team;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
@Rollback(false)
class MemberRepositoryTest {


    // 같은 트랜잭션 내에선 동일한 EntityManger를 사용함
    @Autowired private MemberRepository memberRepository;
    @Autowired private TeamRepository teamRepository;
    @PersistenceContext private EntityManager em;

    @Test
    public void testMember(){
        Member member = new Member("memberA");
        Member savedMember = memberRepository.save(member);

        Member findMember = memberRepository.findById(savedMember.getId()).get(); // get()해서 가져오는게 그리 좋은방법은 아님. -> 조회해서 없으면 예외발생

        assertThat(findMember.getId()).isEqualTo(member.getId());
        assertThat(findMember.getUsername()).isEqualTo(member.getUsername());
        assertThat(findMember).isEqualTo(member);
    }

    @Test
    public void findByUsernameAndAgeGreaterThen(){
        Member m1 = new Member("AAA", 10, null);
        Member m2 = new Member("AAA", 20, null);
        memberRepository.save(m1);
        memberRepository.save(m2);

        List<Member> result = memberRepository.findByUsernameAndAgeGreaterThan("AAA", 15);

        assertThat(result.get(0).getUsername()).isEqualTo("AAA");
        assertThat(result.get(0).getAge()).isEqualTo(20);
        assertThat(result.size()).isEqualTo(1);
    }

    @Test
    public void testQuery(){
        Member m1 = new Member("AAA", 10, null);
        Member m2 = new Member("AAA", 20, null);
        memberRepository.save(m1);
        memberRepository.save(m2);

        List<Member> result = memberRepository.findUser("AAA", 10);
        assertThat(result.get(0)).isEqualTo(m1);
    }

    @Test
    public void findMemberDto(){
        Team team = new Team("teamA");
        teamRepository.save(team);

        Member m1 = new Member("AAA", 10, team);
        memberRepository.save(m1);


        List<MemberDto> result = memberRepository.findMemberDto();
        for (MemberDto memberDto : result) {
            System.out.println("member name = " + memberDto.getUsername());
            System.out.println("member team name = " + memberDto.getTeamName());
        }
    }

    @Test
    public void findByNames(){
        Member m1 = new Member("AAA", 10, null);
        Member m2 = new Member("BBB", 20, null);
        memberRepository.save(m1);
        memberRepository.save(m2);

        List<Member> result = memberRepository.findByNames(Arrays.asList("AAA", "BBB"));
        for (Member member : result) {
            System.out.println("member name = " + member.getUsername());
        }

    }

    @Test
    public void returnType(){
        Member m1 = new Member("AAA", 10, null);
        Member m2 = new Member("BBB", 20, null);
        memberRepository.save(m1);
        memberRepository.save(m2);

        List<Member> aaaList = memberRepository.findListByUsername("AAA"); // 컬렉션 반환시 매칭되는게 없을경우 Null이 반환되는게 아니라 Empty Collection반환함
        Member aaaMember = memberRepository.findMemberByUsername("AAA");    // JPA는 singleResult해서 없으면 NoResult예외발생하는데 data JPA는 없으면 null값반환해줌

        // Null이 들어있을수도 있고, 아닐수도있을경우 Optional 사용
        // 단건 조회기때문에 여러개 결과 나오면 Exception발생함 -> JPA에서 발생한 예외 Spring Data JPA가 받아서 Spring 예외타입으로 변환해서 출력해줌
        // (Repository에 쓰는 기술이 JPA가아닌 다른걸 쓰는경우(MongoDB, JDBC 등)에도 클라이언트 코드를 변경하지 않아도 되는 장점이 있음)
        Optional<Member> aaaOptional = memberRepository.findOptionByUsername("AAA");

    }

    @Test
    public void paging(){
        // given
        memberRepository.save(new Member("member1", 10));
        memberRepository.save(new Member("member2", 10));
        memberRepository.save(new Member("member3", 10));
        memberRepository.save(new Member("member4", 10));
        memberRepository.save(new Member("member5", 10));

        int age = 10;
        // Spring data JPA 페이징은 0페이지부터 시작함. 아래는 0페이지에서 3개가져와서 username 역순으로 가져옴
        PageRequest pageRequest = PageRequest.of(0, 3, Sort.by(Sort.Direction.DESC, "username"));

        //when

        // 반환타입 Page로하면 totalCount 쿼리까지 같이 보내서 가져옴
        // Slice로하면 토탈카운트 가져오진않고 limit에 +1 해서 쿼리 보냄
         Page<Member> page = memberRepository.findByAge(age, pageRequest);
//        Slice<Member> page = memberRepository.findByAge(age, pageRequest);

        // Entity -> Dto변환
        Page<MemberDto> convertedPage = page.map(member -> new MemberDto(member.getId(), member.getUsername(), null));

        //then
        List<Member> content = page.getContent(); // Page타입 반환받은거에서 들어있는 내용 갖고오려면 .getContent();
//        long totalElements = page.getTotalElements();
        for (Member member : content) {
            System.out.println(member.getUsername());
        }

        assertThat(content.size()).isEqualTo(3);
//        assertThat(page.getTotalElements()).isEqualTo(5);
        assertThat(page.getNumber()).isEqualTo(0);
//        assertThat(page.getTotalPages()).isEqualTo(2);
        assertThat(page.isFirst()).isTrue();
        assertThat(page.hasNext()).isTrue();

    }

    @Test
    public void bulkAgePlus(){
        // given
        memberRepository.save(new Member("member1", 10));
        memberRepository.save(new Member("member2", 19));
        memberRepository.save(new Member("member3", 20));
        memberRepository.save(new Member("member4", 21));
        memberRepository.save(new Member("member5", 40));

        //when
        /**
         * 주의 *
         * Spring data Jpa이용해서 벌크연산시 JPA의 영속성 컨텍스트에 저장된 객체를 수정하는게 아니라 DB자체의 데이터를 수정하기때문에
         * 영속성 컨텍스트에 저장된 객체값이 변하는게 아님. 따라서 벌크연산 후에는 영속성컨텍스트를 초기화해줘야함
         * em.clear해주던지, repository에 적은 벌크연산 쿼리의 @Modifying(clearAutomatically = true)해주던지 해야함
         * JDBC, MyBatis등과 같이 사용할경우 이 라이브러리들이 보낸 쿼리는 JPA와 관련이 없기때문에 데이터 수정시 영속성컨텍스트 초기화 한번 해줘야됨
         */
        int resultCount = memberRepository.bulkAgePlus(20);
        em.clear();

        Member findMember = memberRepository.findMemberByUsername("member5");
        System.out.println("member age = " + findMember.getAge());

        // 페이지 계산공식적용
        // totalPage = totalCount / size ...
        // 마지막페이지
        // 최초페이지

        //then
        assertThat(resultCount).isEqualTo(3);

    }

    @Test
    public void findMemberLazy(){
        //given
        //member1 -> teamA
        //member2 -> teamB

        Team teamA = new Team("teamA");
        Team teamB = new Team("teamB");
        teamRepository.save(teamA);
        teamRepository.save(teamB);

        Member member1 = new Member("member1", 10, teamA);
        Member member2 = new Member("member2", 10, teamB);
        memberRepository.save(member1);
        memberRepository.save(member2);

        em.flush();
        em.clear();

        //when
//        List<Member> findMembers = memberRepository.findAll(); // <- 그냥 select해온경우 = 지연로딩에의한 N+1문제
//        List<Member> findMembers = memberRepository.findMemberFetchJoin();
//        List<Member> findMembers2 = memberRepository.findAll();  // JPQL안쓰고도 EntityGraph써서 fetch join해옴
        List<Member> findMembers = memberRepository.findEntityGraphByUsername("member2"); // 메소드명+@Param으로 페치조인해옴
        for (Member findMember : findMembers) {
            System.out.println("member = " + findMember.getUsername());
            System.out.println("team = " + findMember.getTeam().getName());
        }

    }

    @Test
    public void queryHint(){
        //given
        Member member1 = memberRepository.save(new Member("member1", 10));
        em.flush();
        em.clear();

        //when
        Member findMember = memberRepository.findById(member1.getId()).get();
        em.flush();

    }

    @Test
    public void callCustom(){
        List<Member> result = memberRepository.findMemberCustom();
        result.forEach(m -> {
            System.out.println(m.getUsername());
        });
    }

    // Projections = DB에서 필요한 필드만 조회하도록 쿼리를 최적화하는 기능 <- Query DSL이 훨좋다
    @Test
    public void projections(){
        Team teamA = new Team("teamA");
        em.persist(teamA);

        Member m1 = new Member("m1", 0, teamA);
        Member m2 = new Member("m2", 0, teamA);
        em.persist(m1);
        em.persist(m2);

        em.flush();
        em.clear();

        //when
        List<UsernameOnly> result = memberRepository.findProjectionsByUsername(m1.getUsername());
        List<UsernameOnlyDto> result2 = memberRepository.findProjectionsDtoByUsername("m1");
        List<UsernameOnlyDto> result3 = memberRepository.findProjectionsGenericByUsername("m1", UsernameOnlyDto.class);
        List<NestedClosedProjections> result4 = memberRepository.findProjectionsGenericByUsername("m1", NestedClosedProjections.class);

        // Interface구현 프로젝션
        for (UsernameOnly usernameOnly : result) {
            System.out.println("usernameOnly = " + usernameOnly);
        }
        // Dto이용 프로젝션
        for (UsernameOnlyDto usernameOnlyDto : result2) {
            System.out.println("usernameDto = " + usernameOnlyDto.getUsername());
        }
        // 동적 프로젝션(제네릭으로 반환타입 바꿀수있음)
        for (UsernameOnlyDto usernameOnlyDto : result3) {
            System.out.println("usernameDto = " + usernameOnlyDto.getUsername());
        }
        // 중첩 프로젝션(DTO나 반환타입의 필드값을 가져오는건 최적화되서 필요한 컬럼데이터만 가져옴, Root는 최적화해서 잘 가져옴)
        // 이후 연관관계에 있는 데이터값을 가져올땐 엔티티 통째로 다가져옴 <- 최적화 안됨
        // 즉, 프로젝션 대상이 Root이면 최적화 가능, 프로젝션 대상이 Root이 아니면 left join, 모든 필드를 다 가져와서 어플리케이션에서 따로 바인딩
        for (NestedClosedProjections nestedClosedProjections : result4) {
            System.out.println("username = " + nestedClosedProjections.getUsername());
            System.out.println("teamname = " + nestedClosedProjections.getTeam().getName());
            System.out.println("nestedClosedProjections = " + nestedClosedProjections);
        }
    }

    // NativeQuery사용법 <- 한계가 너무 많음 (엔티티에 맞게 쿼리를 만들어야하므로, 엔티티가 변경되면 죄다 수정해야함)
    // JPQL처럼 애플리케이션 로딩시점에 문법확인 불가, 동적쿼리 안됨, 반환타입도 제약이있음
    // 쓸거면 JdbcTemplate or MyBatis 연동해서 쓸것.
    @Test
    public void nativeQuery(){
        Team teamA = new Team("teamA");
        em.persist(teamA);

        Member m1 = new Member("m1", 0, teamA);
        Member m2 = new Member("m2", 0, teamA);
        em.persist(m1);
        em.persist(m2);

        em.flush();
        em.clear();

        //when
//        Member findMember = memberRepository.findByNativeQuery("m1");
        Page<MemberProjection> result = memberRepository.findByNativeProjection(PageRequest.of(0, 10)); // nativeProjection사용
        List<MemberProjection> content = result.getContent();
        for (MemberProjection memberProjection : content) {
            System.out.println("username = " + memberProjection.getUsername());
            System.out.println("teamname = " + memberProjection.getTeamName());
        }
    }


}