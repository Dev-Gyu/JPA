package jpabook.jpashop.service;

import jpabook.jpashop.domain.item.Book;
import jpabook.jpashop.domain.item.Item;
import jpabook.jpashop.repository.ItemRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class ItemService {

    private final ItemRepository itemRepository;

    @Transactional(readOnly = false)
    public void saveItem(Item item){
        itemRepository.save(item);
    }

    public List<Item> findItems(){
        return itemRepository.findAll();
    }

    public Item findOne(Long itemId){
        return itemRepository.findOne(itemId);
    }

    /**
     * 1.Controller에서 어설프게 객체 생성하지마라. (서비스에서 jpa로 객체 조회 해서 영속성컨텍스트에 객체 등록한걸 받아라)
     * 2.Controller에서 서비스로 업데이트 할때 Id값과 변경할 값을 정확하게 전달해라.
     * 3.Repository에서 받은 객체에 직접 값을 변경해서 트랜잭션 Commit시 JPA가 변경감지해서 업데이트하도록 구성해라.
     */
    public void updateItem(Long itemId, String name, int price, int stockQuantity) {
        Book item = (Book) itemRepository.findOne(itemId);
        // 엥간하면 엔티티안에 셋팅해주는 메소드 하나 만들어서 그것만 호출하도록 할것
        item.setName(name);
        item.setPrice(price);
        item.setStockQuantity(stockQuantity);

    }
}
