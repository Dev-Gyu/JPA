package jpabook.jpashop.service;

import jpabook.jpashop.domain.Member;
import jpabook.jpashop.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true) // public method에는 자동으로 트랜잭션이 걸려서 동작함
@RequiredArgsConstructor // final이 붙은 필드만 생성자메소드에서 인자로 받아 초기화해주는 역할. ( 가장 권장되는 의존주입 방식 )
public class MemberService {

    // 이 필드의 참조값을 바꿀일이 없기때문에 final 선언함 ( 컴파일단계에서 초기화 됐는지 안됐는지 에러 확인 가능 )
    private final MemberRepository memberRepository;

    /**
    // 가장 권장되는 의존성 주입 방식(Spring Boot의 경우 @Autowired없고 생성자 하나만 있는경우 알아서 의존 주입해줌 = 롬복 requiredArgsConstructor 사용가능)
    @Autowired
    public MemberService(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }
    */

    /**
     * 회원 가입
     * 클래스단위의 글로벌 트랜잭션에서 readOnly = true 이므로 로컬 트랜잭션에서 readOnly = false 해줘야 데이터 변경 가능함
     * 안하면 읽기전용 트랜잭션으로 동작. ( 조회하는 메소드가 더 많아서 글로벌로 readOnly = true 해둔것 )
     */
    @Transactional(readOnly = false)
    public Long join(Member member){
        validateDuplicateMember(member); // 중복 회원 검증
        memberRepository.save(member);
        return member.getId();
    }

    // 멤버 중복체크
    private void validateDuplicateMember(Member member){
        // 동시에 같은 아이디로 가입시도하는 경우가 있기때문에 DB에서 name컬럼을 unique조건 걸어두는게 좋음
        List<Member> findMembers = memberRepository.findByName(member.getName());
        if(!findMembers.isEmpty()){
            throw new IllegalStateException("이미 존재하는 회원입니다.");
        }
    }
    /**
     * 회원 전체 조회
     * 단순히 읽기전용의 트랜잭션일경우 readOnly속성을 true로 해주면 최적화에 좋다.(읽기전용은 데이터 변경 안됨)
     */
    // @Transactional(readOnly = true)
    public List<Member> findMembers(){
        return memberRepository.findAll();
    }

    /**
     * 회원 한명 조회
     */
   // @Transactional(readOnly = true)
    public Member findOne(Long id){
        return memberRepository.findOne(id);
    }

    // 변경감지
    @Transactional
    public void update(Long id, String name) {
        Member member = memberRepository.findOne(id);
        member.setName(name);
    }
}
