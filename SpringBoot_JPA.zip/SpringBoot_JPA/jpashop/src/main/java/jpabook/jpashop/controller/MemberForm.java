package jpabook.jpashop.controller;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;

/**
 * Entity 만으로 직접 사용해도 되지만 view 단에 의존적인 기능이 추가될경우 Entity 자체가 지저분해질 수 있기 때문에
 * DTO(Command Object)를 생성해서 쓰는것이 좋다. 즉, 복잡하면 DTO 만들어서 필요한 값만 지정해서 써라.
 * API 개발시엔 Entity 절대 사용하면 안됨.
 */
@Getter
@Setter
public class MemberForm {

    @NotEmpty(message = "회원 이름은 필수 입니다.")
    private String name;
    private String city;
    private String street;
    private String zipcode;
}
