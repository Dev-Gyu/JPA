package jpabook.jpashop.repository;

import jpabook.jpashop.domain.item.Item;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class ItemRepository {

    private final EntityManager em;

    public void save(Item item){
        /**
         * JPA 에서 권장하는 업데이트방식 = 변경감지 이용
         * (Service 단에서 객체 Id가져와서 조회한뒤 setter나 생성자등으로 값 바꿔주면 트랜잭션Commit시 jpa가 자동으로 감지해서 변경하는것)
         * merge 는 인자로 준 객체 값을 전부 인자의 필드값으로 바꿔버리고 저장하기 때문에
         * 중간에 setter메소드 빠지거나 변경하지 않을시 null값이 DB에 들어가는 예상하지못한 결과가 있을 수 있음
         * 예제에선 이렇게 만들지만 실무에선 반드시 변경감지 쓸것 = 그냥 merge 쓰지마라
         */
        if (item.getId() == null){
            em.persist(item);
        } else{
            em.merge(item); // 인자로 준 item이 영속성객체로 관리되는것이 아니라 em.merge해서 반환된 객체가 영속성객체로 등록됨
        }
    }

    public Item findOne(Long id){
        return em.find(Item.class, id);
    }

    public List<Item> findAll(){
        return em.createQuery("select m from Item m")
                .getResultList();
    }
}
