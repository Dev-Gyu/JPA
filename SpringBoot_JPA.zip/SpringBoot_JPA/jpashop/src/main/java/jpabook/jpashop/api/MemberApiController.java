package jpabook.jpashop.api;

import jpabook.jpashop.domain.Member;
import jpabook.jpashop.service.MemberService;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequiredArgsConstructor
public class MemberApiController {

    private final MemberService memberService;

    /**
     * 엔티티는 파라미터 받을때 쓰지말것. 받아야 하는 필드만으로 구성된 맞춤형 DTO만들어서 파라미터 받을것. + 엔티티 외부노출 하지마라
     * 엔티티는 여러곳에서 사용하기 때문에 엔티티로 파라미터 받고 validation등 뭘 하면 예상치 못한 일이 일어날 수 있음( side effect ) + 엔티티 변경하면 API전체 스펙이 바뀜
     * 즉, saveMemberV2처럼 해라
     */

    @PostMapping("/api/v1/members")
    public CreateMemberResponse saveMemberV1(@RequestBody @Valid Member member){
        Long joinId = memberService.join(member);
        return new CreateMemberResponse(joinId);
    }

    @PostMapping("/api/v2/members")
    public CreateMemberResponse saveMemberV2(@RequestBody @Valid CreateMemberRequest request){
        Member member = new Member();
        member.setName(request.getName());

        Long joinId = memberService.join(member);
        return new CreateMemberResponse(joinId);
    }

    // 멤버 조회할때 Orders정보까지 같이 나갈수가있는데 이경우 @JsonIgnore를 쓸순있으나
    // 이럴경우 View단을 위한 로직이 엔티티에 들어감 -> view단과의 연관성이 높아짐. 또한 엔티티가 변경되면 API스펙이 변경됨(가장큰문제)
    @GetMapping("/api/v1/members")
    public List<Member> membersV1(){
        return memberService.findMembers();
    }
    @GetMapping("/api/v2/members")
    public Result memberV2(){
        List<Member> members = memberService.findMembers();
        List<MemberDto> collect = members.stream() // enhanced For문 사용해서 MemberDto 세팅한거랑 같은결과 나옴
                .map(m -> new MemberDto(m.getName()))
                .collect(Collectors.toList());

        // 멤버 데이터 뿐만아니라 다른 데이터도 포함시킬경우도 대비하여 Result로 한번 더 감싸서 데이터 보냄
        // +@로 엔티티 변경해도 API스펙이 변하진않음 (여기선 Member클래스의 getter만 바꿔주면됨)
        return new Result(collect.size(), collect);
    }
    @Data
    @AllArgsConstructor
    static class Result<T>{
        private int count;
        private T data;
    }
    @Data
    @AllArgsConstructor
    static class MemberDto{
        private String name;
    }


    @PutMapping("/api/v2/members/{id}")
    public UpdateMemberResponse updateMemberV2(@PathVariable("id") Long id,
                                               @RequestBody @Valid UpdateMemberRequest request){
        memberService.update(id, request.getName());
        Member findMember = memberService.findOne(id);
        return new UpdateMemberResponse(findMember.getId(), findMember.getName());

    }


    // Member 수정용 DTO
    @Data
    static class UpdateMemberRequest{
        private String name;
    }

    @Data
    @AllArgsConstructor
    static class UpdateMemberResponse{
        private Long id;
        private String name;
    }

    // Member 생성용 DTO
    @Data
    static class CreateMemberRequest{
        /**
         * 맞춤형 DTO 쓰면 좋은이유
         * JPA Commit시 null이나 이상한값에 의한 업데이트가 일어날 가능성이 없음
         * 파라미터가 어떤것이 넘어오는지 정확하게 알 수 있음 ( 엔티티는 뭘 받아오는지 모름 )
         * Validation등의 추가적인 작업등이 용이함. => 유지보수 좋아짐
         */
        @NotEmpty
        private String name;
    }

    @Data
    @AllArgsConstructor
    static class CreateMemberResponse {
        private Long id;
    }
}
