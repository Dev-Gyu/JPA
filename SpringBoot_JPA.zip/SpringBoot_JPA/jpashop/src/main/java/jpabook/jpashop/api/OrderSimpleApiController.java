package jpabook.jpashop.api;

import jpabook.jpashop.domain.Address;
import jpabook.jpashop.domain.Order;
import jpabook.jpashop.domain.OrderStatus;
import jpabook.jpashop.repository.OrderRepository;
import jpabook.jpashop.repository.OrderSearch;
import jpabook.jpashop.repository.OrderSimpleQueryDto;
import jpabook.jpashop.repository.order.simplequery.OrderSimpleQueryRepository;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * xToOne관계 (다대일, 일대일관계에서의 성능최적화)
 * Order
 * Order -> Member
 * Order -> Delivery
 */
@RestController
@RequiredArgsConstructor
public class OrderSimpleApiController {
    private final OrderRepository orderRepository;

    private final OrderSimpleQueryRepository orderSimpleQueryRepository;

    @GetMapping("/api/v1/simple-orders")
    public List<Order> ordersV1(){
        // order안에 member가있는데, member는 다시 orders가있음 -> 무한루프
        // 이걸 피하려고 양방향 연관관계에서 jsonIgnore하면 fetch정책이 Lazy이므로 프록시객체가 jackson에 의해 바인딩되는데 예외발생함
        // 프록시객체 로딩 안시키려면 Hibernate5Module 써야됨 -> 지연로딩인 객체 정보 로딩 무시하고 null값으로 바인딩시킴.
        // 옵션쓰면 레이지로딩도 가져올수있는데 이러면 필요없는 데이터도 가져와서 성능이 너무떨어짐
        List<Order> all = orderRepository.findAllByString(new OrderSearch());
        return all;
    }

    // DTO를 쓰면 엔티티가 변경되더라도 API 스펙이 변하지않음.
    // 하지만 여전히 LAZY로딩에 의한 N+1문제가 존재함
    @GetMapping("/api/v2/simple-orders")
    public List<SimpleOrderDto> ordersV2(){
        List<Order> orders = orderRepository.findAllByString(new OrderSearch());

        return orders.stream().map(o -> new SimpleOrderDto(o))
                .collect(Collectors.toList());
    }

    // fetch조인 사용해서 DTO로 바인딩해서 반환, 가장권장
    @GetMapping("/api/v3/simple-orders")
    public List<SimpleOrderDto> ordersV3(){
        List<Order> orders = orderRepository.findAllWithMemberDelivery();

        List<SimpleOrderDto> collect = orders.stream().map(o -> new SimpleOrderDto(o)).collect(Collectors.toList());
        return collect;
    }

    // JPA에서 DTO에 바로 맵핑해서 반환하는 경우, fetch조인 안쓰는데 fetch join쓴것처럼 작동 + 필요한 필드만 가져옴 (V3보다 성능최적화는 더 좋은데.. 효과가 미비)
    // 하지만 이 부분에 딱 맞춰서 데이터를 가져온거라 재사용이 어려움 + Entity바꾸면 JPQL도 바꿔줘야됨
    // 따라서 성능 최적화가 필요한 부분은 그 부분만을 위한 쿼리가 모여있는 repository를 따로만들어서 관리함 (OrderSimpleQueryRepository)
    // Default Repository는 순수하게 엔티티만을 조회하는 쿼리가 있어야함
    @GetMapping("/api/v4/simple-orders")
    public List<OrderSimpleQueryDto> ordersV4(){
        return orderSimpleQueryRepository.findOrderDtos();
    }

    @Data
    static class SimpleOrderDto{
        private Long orderId;
        private String name;
        private LocalDateTime orderDate;
        private OrderStatus orderStatus;
        private Address address;

        public SimpleOrderDto(Order order) {
            orderId = order.getId();
            orderDate = order.getOrderDate();
            name = order.getMember().getName(); // LAZY 정책으로 인한 프록시 초기화 -> 쿼리 다량발생
            orderStatus = order.getStatus();
            address = order.getDelivery().getAddress();
        }
    }
}
