package jpabook.jpashop.repository;

import jpabook.jpashop.domain.Member;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
// 생성자 메소드 주입방식을 롬복이용한 것 으로 @PersistenceContext보다 좀 더 나은 주입 방식, Spring Data JPA가 있어서 가능한것
// 원칙은 @PersistenceContext선언해서 주입받아야 하는데, Spring Data JPA에서 @Autowired로도 주입 받을 수 있도록 해줘서 가능함
@RequiredArgsConstructor
public class MemberRepository {
    private final EntityManager em;

    /*
    @PersistenceContext
    private EntityManager em;

     */


    public void save(Member member){
        em.persist(member);
    }

    public Member findOne(Long id){
        return em.find(Member.class, id);
    }

    public List<Member> findAll(){
        return em.createQuery("select m from Member m", Member.class)
                .getResultList();
    }

    public List<Member> findByName(String name){
        return em.createQuery("select m from Member m where m.name = :name", Member.class)
                .setParameter("name", name)
                .getResultList();
    }
}
