package jpabook.jpashop.api;

import jpabook.jpashop.domain.Address;
import jpabook.jpashop.domain.Order;
import jpabook.jpashop.domain.OrderItem;
import jpabook.jpashop.domain.item.Item;
import jpabook.jpashop.repository.OrderRepository;
import jpabook.jpashop.repository.OrderSearch;
import jpabook.jpashop.repository.order.query.OrderFlatDto;
import jpabook.jpashop.repository.order.query.OrderItemQueryDto;
import jpabook.jpashop.repository.order.query.OrderQueryDto;
import jpabook.jpashop.repository.order.query.OrderQueryRepository;
import lombok.Data;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;
import static org.yaml.snakeyaml.nodes.NodeId.mapping;

@RestController
@RequiredArgsConstructor
public class OrderApiController {
    private final OrderRepository orderRepository;
    private final OrderQueryRepository orderQueryRepository;

    // Entity를 직접 노출하기 때문에 쓰지말것
    @GetMapping("/api/v1/orders")
    public List<Order> ordersV1(){
        List<Order> all = orderRepository.findAllByString(new OrderSearch());
        for (Order order : all) {
            order.getMember().getName();
            order.getDelivery().getAddress();

            // 프록시 초기화
            List<OrderItem> items = order.getOrderItems();
            items.stream().forEach(o -> o.getItem().getName());
        }
        return all;

    }

    // Dto안에 entity를 그대로 넣어서 반환하면 안됨. DTO안의 entity도 DTO로 변환해서 보내야됨
    // 값타입객체는 DTO딱히 안 써도됨
    // 이 방식의 경우 fetch join을 안쓰기 때문에 쿼리 대박남
    @GetMapping("/api/v2/orders")
    public List<OrderDto> ordersV2(){
        List<Order> orders = orderRepository.findAllByString(new OrderSearch());
        List<OrderDto> result = orders.stream()
                .map(o -> new OrderDto(o))
                .collect(toList());

        return result;
    }

    /** 컬렉션 fetch join의 경우 Join의 특성때문에 데이터가 기존것보다 뻥튀기돼서 들어감
     * JPQL에서 distinct문 추가하면 JPA가 DB차원의 중복제거 + Application레벨의 중복제거(Entity가 중복인경우를 확인하여 같은거 제거)
     * ******************************* 매.우.중.요 *****************************************
     * 컬렉션 페치 조인을하면 페이징이 안됨. 하이버네이트가 경고 문구 보내면서 어찌저찌 해주긴하지만 메모리상에서 페이징이 이루어지기때문에 데이터많으면 Out of Memory발생할수도있음(쓰지마라)
     * 또한 일대다 조인의 경우 DB에서 조인을하게되면 데이터 뻥튀기가 되는데, 이때 JPQL에 설정한 시작인덱스, 페이징할 인덱스 수가 중복제거가 적용 안된상태로 그냥 페이징 해버리기때문에
     * 일반적으로 생각하는 페이징의 결과가 아닌 다른 페이징 결과가 나올수 있음(ex 다른거 100개가 아니라 같은거 80개 다른거 20개 이럴수도 있다는 얘기)
     * 컬렉션 페치 조인은 반드시 하나만 쓸것. 2개 이상쓰면 JPA가 뭘 기준으로 데이터 바인딩을 해야할지 판단기준이 명확하지 않아 데이터 정합성이 떨어질 수도 있음.
     */
    @GetMapping("/api/v3/orders")
    public List<OrderDto> ordersV3(){
        List<Order> orders = orderRepository.findAllWithItem();
        List<OrderDto> result = orders.stream()
                .map(o -> new OrderDto(o)).collect(toList());
        return result;
    }

    /**
     * **************************************** 또 매우 중요 *************************************************
     * 페이징처리 성능극대화 한계돌파 -> @BatchSize (적용한 트랜잭션에만 적용) persistence.yml에 jpa Properties에 default_batch_fetch_size 값 설정
     */
    @GetMapping("/api/v3.1/orders")
    public List<OrderDto> ordersV3_page(@RequestParam(value = "offset", defaultValue = "0") int offset,
                                        @RequestParam(value = "limit", defaultValue = "100") int limit){
        // 1. ToOne관계에 있는 엔티티들을 전부 페치조인해서 페이징걸어둠(전부 지연로딩걸어둠)
        List<Order> orders = orderRepository.findAllWithMemberDelivery(offset, limit);
        List<OrderDto> result = orders.stream()
                .map(o -> new OrderDto(o)).collect(toList());
        return result;
    }

    // JPA로 DTO 직접 뽑는법
    @GetMapping("/api/v4/orders")
    public List<OrderQueryDto> ordersV4(){
        return orderQueryRepository.findOrderQueryDtos();
    }

    // 쿼리 2번, Order기준으로 Paging불가능(OrderItems때문에 Order가 중복된값이많음)
    @GetMapping("/api/v5/orders")
    public List<OrderQueryDto> ordersV5(){
        return orderQueryRepository.findAllByDto_optimization();
    }

    /**
     * 쿼리 한번으로 v5 처리할수있는방법
     * 쿼리는 한번이지만 통째로 가져온걸 분해해서 세팅해야하기때문에 어플리케이션 레벨에서 성능이 낮아질수있음
     * Order기준으로 Paging불가능
     * 아래 코드 뭔가 안됨;
    @GetMapping("/api/v6/orders")
    public List<OrderQueryDto> ordersV6() {
        List<OrderFlatDto> flats = orderQueryRepository.findAllByDto_flat();
        return flats.stream()
                .collect(groupingBy(o -> new OrderQueryDto(o.getOrderId(),
                        o.getName(), o.getOrderDate(), o.getOrderStatus(), o.getAddress()), mapping(o -> new OrderItemQueryDto(o.getOrderId(),
                        o.getItemName(), o.getOrderPrice(), o.getCount()), toList()) )).entrySet().stream()
                .map(e -> new OrderQueryDto(e.getKey().getOrderId(), e.getKey().getName(), e.getKey().getOrderDate(), e.getKey().getOrderStatus(), e.getKey().getAddress(), e.getValue()))
                .collect(toList());
    }
    */

    @Data
    static class OrderDto{
        private Long orderId;
        private String name;
        private LocalDateTime orderDate;
        private Address address;
        private List<OrderItemDto> orderItems;

        public OrderDto(Order o){
            orderId = o.getId();
            name = o.getMember().getName();
            orderDate = o.getOrderDate();
            address = o.getDelivery().getAddress();
            orderItems = o.getOrderItems().stream()
                    .map(orderItem -> new OrderItemDto(orderItem)).collect(toList());
        }
    }
    // OrderDto내의 OrderItem의 Dto클래스
    @Getter
    static class OrderItemDto{
        private String itemName;
        private int orderPrice;
        private int count;

        public OrderItemDto(OrderItem orderItem){
            itemName = orderItem.getItem().getName();
            orderPrice = orderItem.getOrderPrice();
            count = orderItem.getCount();
        }
    }
}
