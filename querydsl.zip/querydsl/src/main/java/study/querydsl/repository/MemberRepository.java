package study.querydsl.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import study.querydsl.controller.entity.Member;

import java.util.List;

/**
 * Spring Data JPA를 이용한 Repository 정의
 * MemberRepositoryCustom : 사용자 정의 Custom Repository
 */
public interface MemberRepository extends JpaRepository<Member, Long>, MemberRepositoryCustom {

    List<Member> findByUsername(String username);

}
