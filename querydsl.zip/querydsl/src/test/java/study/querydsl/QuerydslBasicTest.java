package study.querydsl;

import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.QueryResults;
import com.querydsl.core.Tuple;
import com.querydsl.core.types.ExpressionUtils;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.Projections;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.core.types.dsl.CaseBuilder;
import com.querydsl.core.types.dsl.Expressions;
import com.querydsl.jpa.JPAExpressions;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
import study.querydsl.dto.MemberDto;
import study.querydsl.controller.entity.Member;
import study.querydsl.controller.entity.QMember;
import study.querydsl.controller.entity.Team;
import study.querydsl.dto.QMemberDto;
import study.querydsl.dto.UserDto;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.TypedQuery;
import java.util.List;

import static org.assertj.core.api.Assertions.*;
import static study.querydsl.controller.entity.QMember.*;
import static study.querydsl.controller.entity.QTeam.team;

@SpringBootTest
@Transactional
public class QuerydslBasicTest {

    @Autowired
    EntityManager em;

    // Thread Safe함 -> Transaction이 어떤것에 걸려있느냐에 따라 EntityManager의 데이터 바인딩이 달라지므로
    // 동시에 여러쓰레드에서 접근해도 동시성문제 없음
    JPAQueryFactory queryFactory;

    @BeforeEach
    @Test
    public void testEntity() {
        queryFactory = new JPAQueryFactory(em);

        Team teamA = new Team("teamA");
        Team teamB = new Team("teamB");
        em.persist(teamA);
        em.persist(teamB);

        Member member1 = new Member("member1", 10, teamA);
        Member member2 = new Member("member2", 20, teamA);

        Member member3 = new Member("member3", 30, teamB);
        Member member4 = new Member("member4", 40, teamB);
        em.persist(member1);
        em.persist(member2);
        em.persist(member3);
        em.persist(member4);
    }

    @Test
    public void startJPQL() {
        // member1을 찾아라
        Member findByJPQL = em.createQuery("select m from Member m where m.username = :username", Member.class)
                .setParameter("username", "member1")
                .getSingleResult();

        assertThat(findByJPQL.getUsername()).isEqualTo("member1");
    }

    @Test
    public void startQuerydls() {
        QMember m = new QMember("m"); // 생성자메소드 인자로 주는건 query의 alias를 지정하기 위해 사용. 같은 테이블 조인할때 빼곤 안씀

        QMember m2 = member;

        Member findMember = queryFactory
                .select(member)
                .from(member)
                .where(member.username.eq("member1")) // 파라미터 바인딩 처리
                .fetchOne();

//        // static import
//        Member findMember2 = queryFactory
//                .select(member)
//                .from(member)
//                .where(member.username.eq("member1")) // 파라미터 바인딩 처리
//                .fetchOne();

        assertThat(findMember.getUsername()).isEqualTo("member1");
    }

    /**
     * 검색조건 사용
     * 검색조건은 내가 상상할 수 있는 모든것들이 다 있음 (eq, between, goe, gt, loe, lt, like등등)
     */
    @Test
    public void search() {
        Member findMember = queryFactory
                .selectFrom(member)
                .where(member.username.eq("member1")
                        .and(member.age.between(10, 30)))
                .fetchOne();

        assertThat(findMember.getUsername()).isEqualTo("member1");
    }

    /**
     * where절에 .and() 선언 안해줘도 , 로 구분해서 여러개를 넘기면 자동으로 and로 인식함
     * 이 방식은 여러개의 인자 중 null이 들어오면 해당 인자를 무시함 -> 동적쿼리 만들때 기가막힘
     */
    @Test
    public void searchAndParam() {
        Member findMember = queryFactory
                .selectFrom(member)
                .where(
                        member.username.eq("member1"),
                        member.age.eq(10))
                .fetchOne();

        assertThat(findMember.getUsername()).isEqualTo("member1");
    }

    /**
     * 검색결과 조회
     */
    @Test
    public void resultFetch() {
        List<Member> fetch = queryFactory
                .selectFrom(member)
                .fetch();

        Member fetchOne = queryFactory
                .selectFrom(member)
                .fetchOne();

        Member fetchFirst = queryFactory
                .selectFrom(QMember.member)
                .fetchFirst();

        // fetchResults()로 가져오는 QueryResults의 경우 getTotal() 지원
        QueryResults<Member> result = queryFactory
                .selectFrom(member)
                .fetchResults();

        result.getTotal(); // select count(*) 이라 보면 됨. 총 페이지 몇개인지 가져옴
        List<Member> results = result.getResults();

        // total count 실행 하는 것
        long total = queryFactory
                .selectFrom(member)
                .fetchCount();
    }

    /**
     * 회원 정렬 순서
     * 1. 회원 나이 내림차순(desc)
     * 2. 회원 이름 올림차순(asc)
     * 단 2에서 회원 이름이 없으면 마지막에 출력(nulls last)
     */
    @Test
    public void sort() {
        em.persist(new Member(null, 100));
        em.persist(new Member("member5", 101));
        em.persist(new Member("member6", 102));

        List<Member> result = queryFactory
                .selectFrom(member)
                .where(member.age.eq(100))
                .orderBy(member.age.desc(), member.username.asc().nullsLast())
                .fetch();

        Member member5 = result.get(0);
        Member member6 = result.get(1);
        Member memberNull = result.get(2);

        assertThat(member5.getUsername()).isEqualTo("member5");
        assertThat(member6.getUsername()).isEqualTo("member6");
        assertThat(memberNull.getUsername()).isNull();
    }

    @Test
    public void paging1() {
        List<Member> result = queryFactory
                .selectFrom(member)
                .orderBy(member.username.desc())
                .offset(1) // offset은 0부터 시작
                .limit(2)
                .fetch();

        assertThat(result.size()).isEqualTo(2);
    }

    @Test
    public void paging2() {
        QueryResults<Member> result = queryFactory
                .selectFrom(member)
                .orderBy(member.username.desc())
                .offset(1) // offset은 0부터 시작
                .limit(2)
                .fetchResults();

        assertThat(result.getTotal()).isEqualTo(4);
        assertThat(result.getLimit()).isEqualTo(2);
        assertThat(result.getOffset()).isEqualTo(1);
        assertThat(result.getResults().size()).isEqualTo(2);
    }

    @Test
    public void aggregation() {
        // 조회할 데이터 타입 종류가 많을경우 QueryDSL은 기본적으로 Tuple타입으로 가져옴(QueryDSL Tuple)
        // 이 것보단 DTO로 바인딩해서 가져오는게 더 낫다
        List<Tuple> result = queryFactory
                .select(
                        member.count(),
                        member.age.sum(),
                        member.age.avg(),
                        member.age.max(),
                        member.age.min()
                )
                .from(member)
                .fetch();

        Tuple tuple = result.get(0); // 어짜피 데이터 한줄임
        assertThat(tuple.get(member.count())).isEqualTo(4);
        assertThat(tuple.get(member.age.sum())).isEqualTo(100);
        assertThat(tuple.get(member.age.avg())).isEqualTo(25);
        assertThat(tuple.get(member.age.max())).isEqualTo(40);
        assertThat(tuple.get(member.age.min())).isEqualTo(10);
    }

    /**
     * 팀의 이름과 각 팀의 평균 연령을 구하라.
     */
    @Test
    public void group() throws Exception {
        //given
        List<Tuple> result = queryFactory
                .select(team.name, member.age.avg())
                .from(member)
                .join(member.team, team)
                .groupBy(team.name)
                .fetch();
        Tuple teamA = result.get(0);
        Tuple teamB = result.get(1);

        assertThat(teamA.get(team.name)).isEqualTo("teamA");
        assertThat(teamA.get(member.age.avg())).isEqualTo(15);

        assertThat(teamB.get(team.name)).isEqualTo("teamB");
        assertThat(teamB.get(member.age.avg())).isEqualTo(35);

    }

    /**
     * 팀 A에 속한 모든 회원
     */

    @Test
    public void join() {
        List<Member> result = queryFactory
                .selectFrom(member)
                .join(member.team, team)
                .where(team.name.eq("teamA"))
                .fetch();
        assertThat(result)
                .extracting("username")
                .containsExactly("member1", "member2");
    }

    /**
     * 세타 조인(막 조인: 연관관계가 없는 테이블끼리 조인)
     * 회원의 이름이 팀 이름과 같은 회원 조회
     */
    @Test
    public void theta_join() {
        em.persist(new Member("teamA"));
        em.persist(new Member("teamB"));

        List<Member> result = queryFactory
                .select(member)
                .from(member, team)
                .where(member.username.eq(team.name))
                .fetch();

        assertThat(result)
                .extracting("username")
                .containsExactly("teamA", "teamB");
    }

    /**
     * 회원과 팀을 조인하면서, 팀 이름이 teamA인 팀만 조인, 회원은 모두 조회
     * JPQL = "select m from Member m left join m.team t on t.name = 'teamA'
     */
    @Test
    public void join_on_filtering() {
        List<Tuple> result = queryFactory
                .select(member, team)
                .from(member)
//                .leftJoin(member.team, team).on(team.name.eq("teamA"))

                // on절써서 필터링할때 inner join의 경우는 on이나 where이나 똑같음, 꼭 left join써야할 경우에만 on절 써서 필터링 할것
                .join(member.team, team).where(team.name.eq("teamA"))
                .fetch();

        for (Tuple tuple : result) {
            System.out.println("tuple = " + tuple);
        }

    }

    /**
     * 연관관계 없는 엔티티 외부 조인
     * 회원 이름이 팀 이름과 같은 대상 외부 조인
     */
    @Test
    public void join_on_no_relation() {
        em.persist(new Member("teamA"));
        em.persist(new Member("teamB"));
        em.persist(new Member("teamC"));

        List<Tuple> result = queryFactory
                .select(member, team)
                .from(member)
                // 일반적인 조인은 member.team, team 처럼 엔티티 두개들어감, 세타조인은 조인 오른쪽의 엔티티만 주고 필터링 정책 넣음
                .leftJoin(team)
                .on(member.username.eq(team.name))
                .fetch();
    }

    /**
     * 페 치 조 인 *
     */
    @PersistenceUnit
    EntityManagerFactory emf;

    @Test
    public void noFetchJoin() {
        em.flush();
        em.clear();

        Member findMember = queryFactory
                .selectFrom(member)
                .where(member.username.eq("member1"))
                .fetchOne();

        boolean loaded = emf.getPersistenceUnitUtil().isLoaded(findMember.getTeam());// 해당 엔티티가 프록시 초기화 된건지 안된건지 검증해줌
        assertThat(loaded).as("페치 조인 미적용").isFalse();
    }

    @Test
    public void FetchJoinUse() {
        em.flush();
        em.clear();

        Member findMember = queryFactory
                .selectFrom(member)
                .join(member.team, team).fetchJoin()
                .where(member.username.eq("member1"))
                .fetchOne();

        boolean loaded = emf.getPersistenceUnitUtil().isLoaded(findMember.getTeam());// 해당 엔티티가 프록시 초기화 된건지 안된건지 검증해줌
        assertThat(loaded).as("페치 조인 적용").isTrue();
    }

    /**
     * 서 브 쿼 리 *
     * 나이가 가장 많은 회원을 조회
     */
    @Test
    public void subQuery() {
        // subquery에서 사용하는 Alias는 from에 들어간 Alias명과 중복되면 안됨
        QMember memberSub = new QMember("memberSub");

        List<Member> result = queryFactory
                .selectFrom(member)
                .where(member.age.eq(
                        JPAExpressions
                                .select(memberSub.age.max())
                                .from(memberSub)
                ))
                .fetch();

        assertThat(result).extracting("age")
                .containsExactly(40);
    }

    /**
     * 나이가 평균 이상인 회원
     */
    @Test
    public void subQueryGoe() {
        // subquery에서 사용하는 Alias는 from에 들어간 Alias명과 중복되면 안됨
        QMember memberSub = new QMember("memberSub");

        List<Member> result = queryFactory
                .selectFrom(member)
                .where(member.age.goe(
                        JPAExpressions
                                .select(memberSub.age.avg())
                                .from(memberSub)
                ))
                .fetch();

        assertThat(result).extracting("age")
                .containsExactly(30, 40);
    }

    /**
     * DB에선 데이터만 가져오는용도로 사용하고, 어플리케이션레벨이나 뷰단에서 로직처리해서 쓰는게 좋음
     * Filtering, Group By등의 꼭 필요한 로직만 수행하고 필요한건 Application단에서 처리하는게 좋음.
     * 하지만 꼭 써야할 때가 있으면 아래처럼 하면됨
     * from절에서의 서브쿼리는 지원하지 않음. JPA자체가 지원을 안함
     * 1. 서브쿼리를 join으로 변경한다. (가능할수도, 불가능할수도 있음)
     * 2. 애플리케이션에서 쿼리를 2번 분리해서 실행한다
     * 3. nativeSql을 사용한다
     */
    @Test
    public void selectSubquery() {
        QMember memberSub = new QMember("memberSub");
        List<Tuple> fetch = queryFactory
                .select(member.username,
                        JPAExpressions  // static import가능
                                .select(memberSub.age.avg())
                                .from(memberSub))
                .from(member)
                .fetch();

        for (Tuple tuple : fetch) {
            System.out.println("tuple" + tuple);
        }
    }

    @Test
    public void basicCase() {
        List<String> fetch = queryFactory
                .select(member.age
                        .when(10).then("열살")
                        .when(20).then("스무살")
                        .otherwise("기타"))
                .from(member)
                .fetch();

        for (String s : fetch) {
            System.out.println("age = " + s);
        }
    }

    @Test
    public void complexCase() {
        List<String> fetch = queryFactory
                .select(new CaseBuilder()
                        .when(member.age.between(0, 20)).then("0~20살")
                        .when(member.age.between(21, 30)).then("21~30살")
                        .otherwise("기타"))
                .from(member)
                .fetch();

        for (String s : fetch) {
            System.out.println("age = " + s);
        }
    }

    @Test
    public void constant() {
        List<Tuple> result = queryFactory
                .select(member.username, Expressions.constant("A"))
                .from(member)
                .fetch();
        for (Tuple tuple : result) {
            System.out.println("tuple = " + result);
        }
    }

    /**
     * 문자열 연결 **
     * 생각보다 자주씀
     */
    @Test
    public void concat() {
        // username_age 식으로 문자 연결하는법
        List<String> fetch = queryFactory
                // age는 문자열이 아니기때문에 Long -> String으로 캐스팅 해줘야됨
                // 문자가 아닌것들은 stringValue()로 문자열로 변환가능. Enum처리할떄 많이씀
                .select(member.username.concat("_").concat(member.age.stringValue()))
                .from(member)
                .where(member.username.eq("member1"))
                .fetch();
        for (String s : fetch) {
            System.out.println("s = " + s);
        }
    }

    /**
     * 프로젝션: select대상 지정, SQL에서 조회할 컬럼을 다 정해주는걸 프로젝션이라함
     */
    @Test
    public void simpleProjection() {
        List<String> result = queryFactory
                .select(member.username)
                .from(member)
                .fetch();
        for (String s : result) {
            System.out.println("username = " + s);
        }
    }

    /**
     * Tuple사용, Tuple은 Repository단까지만 사용하고, 이를 DTO로 변환해서 반환하는게 좋음
     * Tuple은 QueryDSL에 종속적인 타입이라 하부 기술을 QueryDSL말고 다른걸로 변환하면 프론트단까지 영향을 미칠 수 있음
     */
    @Test
    public void tupleProjection() {
        List<Tuple> fetch = queryFactory
                .select(member.username, member.age)
                .from(member)
                .fetch();
        for (Tuple tuple : fetch) {
            String username = tuple.get(member.username);
            Integer age = tuple.get(member.age);
            System.out.println("username = " + username);
            System.out.println("age = " + age);
        }
    }

    // 순수 JPQL로 DTO조회 하는 경우, 생성자가 반드시 필요함
    @Test
    public void findDtoByJPQL() {
        List<MemberDto> resultList = em.createQuery("select " +
                "new study.querydsl.dto.MemberDto(m.username, m.age) " +
                "from Member m", MemberDto.class)
                .getResultList();

        for (MemberDto memberDto : resultList) {
            System.out.println("memberDto = " + memberDto);
        }
    }

    // 기본생성자를 호출해서 빈을 생성해 Setter로 주입해주는 방식임
    @Test
    public void findDtoBySetter() {
        List<MemberDto> fetch = queryFactory
                .select(Projections.bean(MemberDto.class,
                        member.username,
                        member.age))
                .from(member)
                .fetch();
        for (MemberDto memberDto : fetch) {
            System.out.println("memberDto = " + memberDto);
        }
    }

    // field접근, getter/setter 안쓰고 바로 필드에 값을 바인딩해버림
    // 필드 접근수준이 private여도 가능함
    @Test
    public void findDtoByFields() {
        List<MemberDto> fetch = queryFactory
                .select(Projections.fields(MemberDto.class,
                        member.username,
                        member.age))
                .from(member)
                .fetch();
        for (MemberDto memberDto : fetch) {
            System.out.println("memberDto = " + memberDto);
        }
    }

    // 만약 DTO의 필드명과 조회할 엔티티의 필드명이 다르면 fields()의 인자에 필드명이 다른컬럼에 .as(DTO필드명)해주면 DTO의 필드명과 매칭해서 바인딩해줌
    @Test
    public void findUserDto() {
        List<UserDto> fetch = queryFactory
                .select(Projections.fields(UserDto.class,
                        member.username.as("name"),
                        member.age))
                .from(member)
                .fetch();
        for (UserDto UserDto : fetch) {
            System.out.println("memberDto = " + UserDto);
        }
    }

    @Test
    public void findUserDto2() {
        QMember memberSub = new QMember("memberSub");
        List<UserDto> fetch = queryFactory
                .select(Projections.fields(UserDto.class,
                        member.username.as("name"),

                        // SubQuery에서의 Dto필드명과 엔티티필드명이 다른경우 이렇게 매칭하면됨
                        ExpressionUtils.as(JPAExpressions
                                .select(memberSub.age.max())
                                .from(memberSub), "age")

                ))
                .from(member)
                .fetch();
        for (UserDto UserDto : fetch) {
            System.out.println("memberDto = " + UserDto);
        }
    }

    // 생성자 접근 방식 프로젝션, 생성자 타입 순서와 Projections.constructor()의 인자 타입 순서 맞아야됨
    // 장점: DTO의 필드명과 엔티티의 필드명이 달라도 타입과 순서만 맞으면 상관없다
    @Test
    public void findDtoByConstructor() {
        List<UserDto> fetch = queryFactory
                .select(Projections.constructor(UserDto.class,
                        member.username,
                        member.age))
                .from(member)
                .fetch();
        for (UserDto UserDto : fetch) {
            System.out.println("memberDto = " + UserDto);
        }
    }

    /**
     * 궁극의 DTO 프로젝션 조회법
     * 가져올 DTO클래스에 가져올 파라미터가 인자로 들어있는 생성자위에 @QueryProjection 선언하고 compileQueryDSL함
     * Q DTO클래스를 new해서 사용하면 됨
     * 장점 = 이 방식은 컴파일수준에서의 예외발생여부 가능 (빨갛게 변함)
     * Constructor프로젝션의 경우 인자 타입과 순서가 맞지않아도 실행시점에서만 예외발생여부 확인가능
     * 단점 = 이 DTO를 그대로 사용하게되는데 해당 DTO가 QueryDSL에 의존적임 <- 아키텍쳐적인 부분의 순수한DTO가 무너질수있음
     * 아키텍쳐적으로 트레이드오프를 해야함. (QueryDSL을 바꿀일이 있으면 안하는게 낫고, 없으면 실용적인 부분에서 쓰는게 낫다)
     */
    @Test
    public void findDtoByQueryProjection() {
        List<MemberDto> result = queryFactory
                .select(new QMemberDto(member.username, member.age))
                .from(member)
                .fetch();
    }

    /**
     * 동적쿼리 *
     * dynamicQuery_BooleanBuilder: BooleanBuilder 이용
     * dynamicQuery_whereParam: where 이용
     */
    @Test
    public void dynamicQuery_BooleanBuilder() {
        String usernameParam = "member1";
        Integer ageParam = null;

        List<Member> result = searchMember1(usernameParam, ageParam);
        assertThat(result.size()).isEqualTo(1);
    }

    private List<Member> searchMember1(String usernameCond, Integer ageCond) {
        // BooleanBuilder는 객체생성시 생성자에 인자넣어줘서 초기값 세팅 가능, 그 값은 null이 올 수 없음
        BooleanBuilder builder = new BooleanBuilder();

        if (usernameCond != null) {
            builder.and(member.username.eq(usernameCond));
        }
        if (ageCond != null) {
            builder.and(member.age.eq(ageCond));
        }

        return queryFactory
                .selectFrom(member)
                .where(builder)
                .fetch();
    }

    /**
     * BooleanBuilder방식보다 직관적임 : 가독성이 높음
     * 코드 재사용, 조합이 용이함 : 코드 유연성이 높음 *
     */
    @Test
    public void dynamicQuery_whereParam() {
        String usernameParam = "member1";
        Integer ageParam = null;

        List<Member> result = searchMember2(usernameParam, ageParam);
        assertThat(result.size()).isEqualTo(1);
    }

    // Awesome && Cool && Sweet
    private List<Member> searchMember2(String usernameCond, Integer ageCond) {
        return queryFactory
                .selectFrom(member)
                .where(usernameEq(usernameCond), ageEq(ageCond)) // where()은 인자값이 null이면 그냥 무시하고 다른인자로 필터링해온다
                .fetch();
    }

    private BooleanExpression usernameEq(String usernameCond) {
        return usernameCond != null ? member.username.eq(usernameCond) : null;
    }

    private BooleanExpression ageEq(Integer ageCond) {
        return ageCond != null ? member.age.eq(ageCond) : null;
    }

    // Null처리 따로 해줘야됨
    private BooleanExpression allEq(String usernameCond, Integer ageCond) {
        return usernameEq(usernameCond).and(ageEq(ageCond));
    }

    // 수정
    @Test
    public void bulkUpdate(){
        // member1 = 10 -> 비회원
        // member2 = 20 -> 비회원
        // member3 = 30 -> 유지
        // member4 = 40 -> 유지

        long count = queryFactory
                .update(member)
                .set(member.username, "비회원")
                .where(member.age.lt(20))
                .execute();
        em.flush();
        em.clear();
    }

    // 더하기
    @Test
    public void bulkAdd(){
        queryFactory
                .update(member)
                .set(member.age, member.age.add(1)) // 모든 회원의 나이 1살 더함, 빼고싶으면 -1 주면됨, 곱하기는 multiply
                .execute();
    }
    // 삭제
    @Test
    public void bulkDelete(){
        queryFactory
                .delete(member)
                .where(member.age.gt(18)) // 나이가 18살 이상인 모든 회원 삭제
                .execute();
    }

    // sql function 호출: 멤버를 조회할때 멤버이름의 member를 M으로 바꿔서 출력
    @Test
    public void sqlFunction(){
        queryFactory
                .select(
                        Expressions.stringTemplate("function('replace', {0}, {1}, {2})",
                                member.username, "member", "M")
                )
                .from(member)
                .fetch();
    }

    @Test
    public void sqlFunction2(){
        List<String> fetch = queryFactory
                .select(member.username)
                .from(member)
//                .where(member.username.eq(
//                        Expressions.stringTemplate("function('lower', {0})", member.username)))
                .where(member.username.eq(member.username.lower())) // ANSI 표준 SQL에 있는 sql함수 지원함. DB특화 함수는 위 주석처럼 별도 적용해야함
                .fetch();

        for (String s : fetch) {
            System.out.println("s = " + s);
        }
    }

}
